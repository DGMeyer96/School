﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sum_of_Numbers_in_String
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool checkFormat(string str)
        {
            string str1 = str.Trim();
            int number;

            char[] delim = { ',' };

            string[] tokens = str1.Split(delim);

            foreach (string str2 in tokens)
            {
                bool result = int.TryParse(str2, out number);
                if(!result)
                {
                    return false;
                }
            }
            
            return true;
        }

        private int sum(string str)
        {
            int total = 0;

            string str1 = str.Trim();

            char[] delim = { ',' };

            string[] tokens = str1.Split(delim);

            foreach(string str2 in tokens)
            {
                total += int.Parse(str2);
            }

            return total;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            String str = tbNumInput.Text;
            int total;
            if(checkFormat(str))
            {
                total = sum(str);
                lblOutput.Text = total.ToString("n1");
            }
            else
            {
                MessageBox.Show("Please use a #, #, #, ... , # format.");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
