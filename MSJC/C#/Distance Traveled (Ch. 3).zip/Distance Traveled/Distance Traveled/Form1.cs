﻿/*
 * Daniel Meyer
 * 0405182
 * C# Level 1
 * Assignment 3
*/ 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Traveled
{
    public partial class Form1 : Form
    {
        private int speed;
        private int time;
        private int distance;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn5hours_Click(object sender, EventArgs e)
        {
            time = 5;
        }

        private void btn8hours_Click(object sender, EventArgs e)
        {
            time = 8;
        }

        private void btn12hours_Click(object sender, EventArgs e)
        {
            time = 12;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            speed = int.Parse(tbSpeed.Text);
            distance = speed * time;
            lblOutput.Text = distance.ToString() + " miles";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbSpeed.Text = "";
            lblOutput.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
