﻿namespace Distance_Traveled
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSpeed = new System.Windows.Forms.Label();
            this.lblDistance = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.tbSpeed = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btn5hours = new System.Windows.Forms.Button();
            this.btn8hours = new System.Windows.Forms.Button();
            this.btn12hours = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSpeed
            // 
            this.lblSpeed.AutoSize = true;
            this.lblSpeed.Location = new System.Drawing.Point(12, 31);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(101, 13);
            this.lblSpeed.TabIndex = 0;
            this.lblSpeed.Text = "Enter speed in mph:";
            // 
            // lblDistance
            // 
            this.lblDistance.AutoSize = true;
            this.lblDistance.Location = new System.Drawing.Point(12, 138);
            this.lblDistance.Name = "lblDistance";
            this.lblDistance.Size = new System.Drawing.Size(93, 13);
            this.lblDistance.TabIndex = 2;
            this.lblDistance.Text = "Distance traveled:";
            // 
            // lblOutput
            // 
            this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOutput.Location = new System.Drawing.Point(111, 133);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(100, 23);
            this.lblOutput.TabIndex = 3;
            this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbSpeed
            // 
            this.tbSpeed.Location = new System.Drawing.Point(119, 28);
            this.tbSpeed.Name = "tbSpeed";
            this.tbSpeed.Size = new System.Drawing.Size(100, 20);
            this.tbSpeed.TabIndex = 5;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(12, 175);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(93, 175);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(174, 175);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btn5hours
            // 
            this.btn5hours.Location = new System.Drawing.Point(12, 64);
            this.btn5hours.Name = "btn5hours";
            this.btn5hours.Size = new System.Drawing.Size(75, 23);
            this.btn5hours.TabIndex = 9;
            this.btn5hours.Text = "5 hours";
            this.btn5hours.UseVisualStyleBackColor = true;
            this.btn5hours.Click += new System.EventHandler(this.btn5hours_Click);
            // 
            // btn8hours
            // 
            this.btn8hours.Location = new System.Drawing.Point(93, 64);
            this.btn8hours.Name = "btn8hours";
            this.btn8hours.Size = new System.Drawing.Size(75, 23);
            this.btn8hours.TabIndex = 10;
            this.btn8hours.Text = "8 hours";
            this.btn8hours.UseVisualStyleBackColor = true;
            this.btn8hours.Click += new System.EventHandler(this.btn8hours_Click);
            // 
            // btn12hours
            // 
            this.btn12hours.Location = new System.Drawing.Point(174, 64);
            this.btn12hours.Name = "btn12hours";
            this.btn12hours.Size = new System.Drawing.Size(75, 23);
            this.btn12hours.TabIndex = 11;
            this.btn12hours.Text = "12 hours";
            this.btn12hours.UseVisualStyleBackColor = true;
            this.btn12hours.Click += new System.EventHandler(this.btn12hours_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 210);
            this.Controls.Add(this.btn12hours);
            this.Controls.Add(this.btn8hours);
            this.Controls.Add(this.btn5hours);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.tbSpeed);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.lblDistance);
            this.Controls.Add(this.lblSpeed);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.Label lblDistance;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.TextBox tbSpeed;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btn5hours;
        private System.Windows.Forms.Button btn8hours;
        private System.Windows.Forms.Button btn12hours;
    }
}

