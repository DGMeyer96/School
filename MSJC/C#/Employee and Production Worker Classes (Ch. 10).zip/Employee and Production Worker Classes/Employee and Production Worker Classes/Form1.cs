﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_and_Production_Worker_Classes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            string name, number;
            int shift = 0;
            decimal payRate;

            name = tbName.Text;
            number = tbNumber.Text;

            if(rbDay.Checked)
            {
                shift = 1;
            }
            else if(rbNight.Checked)
            {
                shift = 2;
            }

            if(decimal.TryParse(tbPayRate.Text, out payRate))
            {
                ProductionWorker pw = new ProductionWorker(name, number, shift, payRate);
                MessageBox.Show(pw.GetInformation);
            }
            else
            {
                MessageBox.Show("Invalid Hourly Pay Rate");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
