﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_Production_Worker_Classes
{
    abstract class Employee
    {
        private string _name;
        private string _number;

        public Employee(string name, string number)
        {
            _name = name;
            _number = number;
        }

        public string EmployeeName
        {
            get { return _name; }
            set { _name = value; }
        }

        public string EmployeeNumber
        {
            get { return _number; }
            set { _number = value; }
        }

        public abstract string GetInformation
        {
            get;
        }
    }
}
