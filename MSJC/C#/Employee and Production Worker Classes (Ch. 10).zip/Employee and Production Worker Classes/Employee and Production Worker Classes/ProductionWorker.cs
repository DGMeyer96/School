﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_and_Production_Worker_Classes
{
    class ProductionWorker : Employee
    {
        private string _shift;
        private decimal _payRate;

        public ProductionWorker(string name, string number, int shift, decimal payRate) : base(name, number)
        {
            if(shift == 1)
            {
                _shift = "Day Shift";
            }
            else if(shift == 2)
            {
                _shift = "Night Shift";
            }
            else
            {
                MessageBox.Show("No Shift Chosen");
            }

            _payRate = payRate;
        }

        public string Shift
        {
            get { return _shift; }
            set { _shift = value; }
        }

        public decimal HourlyPayRate
        {
            get { return _payRate; }
            set { _payRate = value; }
        }

        public override string GetInformation
        {
            get { return EmployeeName + " (#" + EmployeeNumber + ") worked " + Shift + " for " + HourlyPayRate.ToString("c") + " per hour"; }
        }
    }
}
