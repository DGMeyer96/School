﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculating_the_Factorial_of_a_Number
{
    public partial class Factorials : Form
    {
        public Factorials()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int input;
            int factorial = 1;

            input = int.Parse(tbInput.Text);

            if(input > 0)
            {
                for(int i = 1; i <= input; i++)
                {
                    factorial *= i;
                }

                lblOutput.Text = factorial.ToString();
                factorial = 1;
            }
            else
            {
                MessageBox.Show("Enter a nonzero integer.");
                tbInput.Text = "";
                tbInput.Focus();
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
