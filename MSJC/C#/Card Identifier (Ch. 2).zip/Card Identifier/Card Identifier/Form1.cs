﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class cardIdentifier : Form
    {
        public cardIdentifier()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbOne_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "One";
        }

        private void pbTwo_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Two";
        }

        private void pbThree_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Three";
        }

        private void pbFour_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Four";
        }

        private void pbFive_Click(object sender, EventArgs e)
        {
            lblCardName.Text = "Five";
        }
    }
}
