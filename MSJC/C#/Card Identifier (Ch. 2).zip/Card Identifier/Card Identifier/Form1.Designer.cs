﻿namespace Card_Identifier
{
    partial class cardIdentifier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.lblCardName = new System.Windows.Forms.Label();
            this.lblClickCard = new System.Windows.Forms.Label();
            this.pbFive = new System.Windows.Forms.PictureBox();
            this.pbFour = new System.Windows.Forms.PictureBox();
            this.pbThree = new System.Windows.Forms.PictureBox();
            this.pbTwo = new System.Windows.Forms.PictureBox();
            this.pbOne = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbFive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbThree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOne)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(212, 227);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblCardName
            // 
            this.lblCardName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCardName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardName.Location = new System.Drawing.Point(95, 201);
            this.lblCardName.Name = "lblCardName";
            this.lblCardName.Size = new System.Drawing.Size(294, 23);
            this.lblCardName.TabIndex = 1;
            this.lblCardName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblClickCard
            // 
            this.lblClickCard.AutoSize = true;
            this.lblClickCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClickCard.Location = new System.Drawing.Point(153, 9);
            this.lblClickCard.Name = "lblClickCard";
            this.lblClickCard.Size = new System.Drawing.Size(206, 16);
            this.lblClickCard.TabIndex = 2;
            this.lblClickCard.Text = "Click a Card to See its Name";
            this.lblClickCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbFive
            // 
            this.pbFive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFive.Image = global::Card_Identifier.Properties.Resources.Five;
            this.pbFive.Location = new System.Drawing.Point(404, 45);
            this.pbFive.Name = "pbFive";
            this.pbFive.Size = new System.Drawing.Size(82, 146);
            this.pbFive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbFive.TabIndex = 7;
            this.pbFive.TabStop = false;
            this.pbFive.Click += new System.EventHandler(this.pbFive_Click);
            // 
            // pbFour
            // 
            this.pbFour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFour.Image = global::Card_Identifier.Properties.Resources.Four;
            this.pbFour.Location = new System.Drawing.Point(307, 45);
            this.pbFour.Name = "pbFour";
            this.pbFour.Size = new System.Drawing.Size(82, 146);
            this.pbFour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbFour.TabIndex = 6;
            this.pbFour.TabStop = false;
            this.pbFour.Click += new System.EventHandler(this.pbFour_Click);
            // 
            // pbThree
            // 
            this.pbThree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbThree.Image = global::Card_Identifier.Properties.Resources.Three;
            this.pbThree.Location = new System.Drawing.Point(212, 45);
            this.pbThree.Name = "pbThree";
            this.pbThree.Size = new System.Drawing.Size(82, 146);
            this.pbThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbThree.TabIndex = 5;
            this.pbThree.TabStop = false;
            this.pbThree.Click += new System.EventHandler(this.pbThree_Click);
            // 
            // pbTwo
            // 
            this.pbTwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTwo.Image = global::Card_Identifier.Properties.Resources.Two;
            this.pbTwo.Location = new System.Drawing.Point(111, 45);
            this.pbTwo.Name = "pbTwo";
            this.pbTwo.Size = new System.Drawing.Size(82, 146);
            this.pbTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbTwo.TabIndex = 4;
            this.pbTwo.TabStop = false;
            this.pbTwo.Click += new System.EventHandler(this.pbTwo_Click);
            // 
            // pbOne
            // 
            this.pbOne.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOne.Image = global::Card_Identifier.Properties.Resources.One;
            this.pbOne.Location = new System.Drawing.Point(12, 45);
            this.pbOne.Name = "pbOne";
            this.pbOne.Size = new System.Drawing.Size(82, 146);
            this.pbOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbOne.TabIndex = 3;
            this.pbOne.TabStop = false;
            this.pbOne.Click += new System.EventHandler(this.pbOne_Click);
            // 
            // cardIdentifier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 262);
            this.Controls.Add(this.pbFive);
            this.Controls.Add(this.pbFour);
            this.Controls.Add(this.pbThree);
            this.Controls.Add(this.pbTwo);
            this.Controls.Add(this.pbOne);
            this.Controls.Add(this.lblClickCard);
            this.Controls.Add(this.lblCardName);
            this.Controls.Add(this.btnExit);
            this.Name = "cardIdentifier";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.pbFive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbThree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOne)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblCardName;
        private System.Windows.Forms.Label lblClickCard;
        private System.Windows.Forms.PictureBox pbOne;
        private System.Windows.Forms.PictureBox pbTwo;
        private System.Windows.Forms.PictureBox pbThree;
        private System.Windows.Forms.PictureBox pbFour;
        private System.Windows.Forms.PictureBox pbFive;
    }
}

