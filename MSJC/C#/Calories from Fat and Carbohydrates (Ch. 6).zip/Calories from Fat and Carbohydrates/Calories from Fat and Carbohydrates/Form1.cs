﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calories_from_Fat_and_Carbohydrates
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private decimal FatCalories(decimal fat)
        {
            decimal calories;

            calories = fat * 9;

            return calories;
        }

        private decimal CarbCalories(decimal carbs)
        {
            decimal calories;

            calories = carbs * 4;

            return calories;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal fat, carbs, calories;
            
            if(decimal.TryParse(tbFat.Text, out fat))
            {
                calories = FatCalories(fat);
                lblFatOutput.Text = calories.ToString();
            }

            if(decimal.TryParse(tbCarbs.Text, out carbs))
            {
                calories = CarbCalories(carbs);
                lblCarbOutput.Text = calories.ToString();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
