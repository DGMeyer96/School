﻿namespace Calories_from_Fat_and_Carbohydrates
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFat = new System.Windows.Forms.Label();
            this.lblCarbs = new System.Windows.Forms.Label();
            this.tbFat = new System.Windows.Forms.TextBox();
            this.tbCarbs = new System.Windows.Forms.TextBox();
            this.lblFatCal = new System.Windows.Forms.Label();
            this.lblCarbCal = new System.Windows.Forms.Label();
            this.lblFatOutput = new System.Windows.Forms.Label();
            this.lblCarbOutput = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFat
            // 
            this.lblFat.AutoSize = true;
            this.lblFat.Location = new System.Drawing.Point(24, 9);
            this.lblFat.Name = "lblFat";
            this.lblFat.Size = new System.Drawing.Size(96, 13);
            this.lblFat.TabIndex = 0;
            this.lblFat.Text = "Daily Grams of Fat:";
            // 
            // lblCarbs
            // 
            this.lblCarbs.AutoSize = true;
            this.lblCarbs.Location = new System.Drawing.Point(12, 43);
            this.lblCarbs.Name = "lblCarbs";
            this.lblCarbs.Size = new System.Drawing.Size(108, 13);
            this.lblCarbs.TabIndex = 1;
            this.lblCarbs.Text = "Daily Grams of Carbs:";
            // 
            // tbFat
            // 
            this.tbFat.Location = new System.Drawing.Point(126, 6);
            this.tbFat.Name = "tbFat";
            this.tbFat.Size = new System.Drawing.Size(100, 20);
            this.tbFat.TabIndex = 2;
            // 
            // tbCarbs
            // 
            this.tbCarbs.Location = new System.Drawing.Point(126, 40);
            this.tbCarbs.Name = "tbCarbs";
            this.tbCarbs.Size = new System.Drawing.Size(100, 20);
            this.tbCarbs.TabIndex = 3;
            // 
            // lblFatCal
            // 
            this.lblFatCal.AutoSize = true;
            this.lblFatCal.Location = new System.Drawing.Point(32, 83);
            this.lblFatCal.Name = "lblFatCal";
            this.lblFatCal.Size = new System.Drawing.Size(88, 13);
            this.lblFatCal.TabIndex = 4;
            this.lblFatCal.Text = "Calories from Fat:";
            // 
            // lblCarbCal
            // 
            this.lblCarbCal.AutoSize = true;
            this.lblCarbCal.Location = new System.Drawing.Point(20, 112);
            this.lblCarbCal.Name = "lblCarbCal";
            this.lblCarbCal.Size = new System.Drawing.Size(100, 13);
            this.lblCarbCal.TabIndex = 5;
            this.lblCarbCal.Text = "Calories from Carbs:";
            // 
            // lblFatOutput
            // 
            this.lblFatOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFatOutput.Location = new System.Drawing.Point(126, 78);
            this.lblFatOutput.Name = "lblFatOutput";
            this.lblFatOutput.Size = new System.Drawing.Size(100, 23);
            this.lblFatOutput.TabIndex = 6;
            this.lblFatOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCarbOutput
            // 
            this.lblCarbOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCarbOutput.Location = new System.Drawing.Point(126, 107);
            this.lblCarbOutput.Name = "lblCarbOutput";
            this.lblCarbOutput.Size = new System.Drawing.Size(100, 23);
            this.lblCarbOutput.TabIndex = 7;
            this.lblCarbOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(23, 136);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 8;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(151, 136);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(246, 171);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblCarbOutput);
            this.Controls.Add(this.lblFatOutput);
            this.Controls.Add(this.lblCarbCal);
            this.Controls.Add(this.lblFatCal);
            this.Controls.Add(this.tbCarbs);
            this.Controls.Add(this.tbFat);
            this.Controls.Add(this.lblCarbs);
            this.Controls.Add(this.lblFat);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFat;
        private System.Windows.Forms.Label lblCarbs;
        private System.Windows.Forms.TextBox tbFat;
        private System.Windows.Forms.TextBox tbCarbs;
        private System.Windows.Forms.Label lblFatCal;
        private System.Windows.Forms.Label lblCarbCal;
        private System.Windows.Forms.Label lblFatOutput;
        private System.Windows.Forms.Label lblCarbOutput;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
    }
}

