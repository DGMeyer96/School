﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Class
{
    class Car
    {
        public int year;
        public string make;
        public int speed;

        public Car(int year, string make)
        {
            this.year = year;
            this.make = make;
            this.speed = 0;
        }

        public void Accelerate()
        {
            this.speed += 5;
        }

        public void Brake()
        {
            this.speed -= 5;
        }
    }
}
