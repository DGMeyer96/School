﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Class
{
    public partial class Form1 : Form
    {
        List<Car> carList = new List<Car>();

        private int index;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAddCar_Click(object sender, EventArgs e)
        {
            int year;
            string make;

            if(int.TryParse(tbYear.Text, out year))
            {
                make = tbMake.Text;

                Car newCar = new Car(year, make);

                carList.Add(newCar);

                lbCars.Items.Add(newCar.year + " " + newCar.make);

                tbYear.Clear();
                tbMake.Clear();

                tbYear.Focus();
            }
            else
            {
                MessageBox.Show("Invalid year");
            } 
        }

        private void btnAccelerate_Click(object sender, EventArgs e)
        {
            carList[index].Accelerate();
            lblCurrentSpeed.Text = carList[index].speed.ToString("n1");
        }

        private void btnBrake_Click(object sender, EventArgs e)
        {
            carList[index].Brake();
            lblCurrentSpeed.Text = carList[index].speed.ToString("n1");
        }

        private void lbCars_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = lbCars.SelectedIndex;

            lblCurrentSpeed.Text = carList[index].speed.ToString("n1");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
