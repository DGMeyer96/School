﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            int input;
            String output = "";

            if(int.TryParse(tbNumber.Text, out input))
            {
                if(input > 1 || input < 10)
                {
                    switch(input)
                    {
                        case 1:
                            output = "I";
                            break;
                        case 2:
                            output = "II";
                            break;
                        case 3:
                            output = "III";
                            break;
                        case 4:
                            output = "IV";
                            break;
                        case 5:
                            output = "V";
                            break;
                        case 6:
                            output = "VI";
                            break;
                        case 7:
                            output = "VII";
                            break;
                        case 8:
                            output = "VIII";
                            break;
                        case 9:
                            output = "IX";
                            break;
                        case 10:
                            output = "X";
                            break;
                    }
                }
                else
                {
                    output = "ERROR";
                }
            }
            else
            {
                output = "ERROR";
            }

            lblRomanNumeral.Text = output;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
