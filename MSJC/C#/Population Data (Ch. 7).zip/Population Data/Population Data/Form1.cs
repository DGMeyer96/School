﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Population_Data
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double averageChange(List<int> yList)
        {
            int total = 0;
            double average;

            for(int i = 0; i < yList.Count; i++)
            {
                total += yList[i];
            }

            average = (double)total / yList.Count;

            return average;
        }

        private int greatestChange(List<int> yList)
        {
            int greatest = yList[1] - yList[0];
            int change;
            int year = 1950;

            for(int i = 2; i < yList.Count; i++)
            {
                change = yList[i] - yList[i - 1];

                if(change > greatest)
                {
                    greatest = change;
                    year = 1950 + i;
                }
            }

            return year;
        }

        private int lowestChange(List<int> yList)
        {
            int lowest = yList[1] - yList[0];
            int change;
            int year = 1950;

            for(int i = 2; i < yList.Count; i++)
            {
                change = yList[i] - yList[i - 1];

                if(change > lowest)
                {
                    lowest = change;
                    year = 1950 + i;
                }
            }

            return year;
        }

        private void lblCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double average;
                int highest;
                int lowest;
                List<int> yList = new List<int>();
                StreamReader input = File.OpenText("USPopulation.txt");

                while(!input.EndOfStream)
                {
                    yList.Add(int.Parse(input.ReadLine()));
                }

                input.Close();

                average = averageChange(yList);
                lblAverage.Text = average.ToString();

                highest = greatestChange(yList);
                lblGreatestChange.Text = highest.ToString();

                lowest = lowestChange(yList);
                lblLeastChange.Text = lowest.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
