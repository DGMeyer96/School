﻿namespace Population_Data
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAnnualChange = new System.Windows.Forms.Label();
            this.lblGreatestYear = new System.Windows.Forms.Label();
            this.lblLeastYear = new System.Windows.Forms.Label();
            this.lblAverage = new System.Windows.Forms.Label();
            this.lblLeastChange = new System.Windows.Forms.Label();
            this.lblGreatestChange = new System.Windows.Forms.Label();
            this.lblCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAnnualChange
            // 
            this.lblAnnualChange.AutoSize = true;
            this.lblAnnualChange.Location = new System.Drawing.Point(26, 14);
            this.lblAnnualChange.Name = "lblAnnualChange";
            this.lblAnnualChange.Size = new System.Drawing.Size(126, 13);
            this.lblAnnualChange.TabIndex = 0;
            this.lblAnnualChange.Text = "Average Annual Change:";
            // 
            // lblGreatestYear
            // 
            this.lblGreatestYear.AutoSize = true;
            this.lblGreatestYear.Location = new System.Drawing.Point(12, 43);
            this.lblGreatestYear.Name = "lblGreatestYear";
            this.lblGreatestYear.Size = new System.Drawing.Size(140, 13);
            this.lblGreatestYear.TabIndex = 1;
            this.lblGreatestYear.Text = "Year With Greatest Change:";
            // 
            // lblLeastYear
            // 
            this.lblLeastYear.AutoSize = true;
            this.lblLeastYear.Location = new System.Drawing.Point(26, 71);
            this.lblLeastYear.Name = "lblLeastYear";
            this.lblLeastYear.Size = new System.Drawing.Size(126, 13);
            this.lblLeastYear.TabIndex = 2;
            this.lblLeastYear.Text = "Year With Least Change:";
            // 
            // lblAverage
            // 
            this.lblAverage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAverage.Location = new System.Drawing.Point(158, 9);
            this.lblAverage.Name = "lblAverage";
            this.lblAverage.Size = new System.Drawing.Size(100, 23);
            this.lblAverage.TabIndex = 3;
            this.lblAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLeastChange
            // 
            this.lblLeastChange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLeastChange.Location = new System.Drawing.Point(158, 66);
            this.lblLeastChange.Name = "lblLeastChange";
            this.lblLeastChange.Size = new System.Drawing.Size(100, 23);
            this.lblLeastChange.TabIndex = 4;
            this.lblLeastChange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGreatestChange
            // 
            this.lblGreatestChange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGreatestChange.Location = new System.Drawing.Point(158, 38);
            this.lblGreatestChange.Name = "lblGreatestChange";
            this.lblGreatestChange.Size = new System.Drawing.Size(100, 23);
            this.lblGreatestChange.TabIndex = 5;
            this.lblGreatestChange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCalculate
            // 
            this.lblCalculate.Location = new System.Drawing.Point(56, 96);
            this.lblCalculate.Name = "lblCalculate";
            this.lblCalculate.Size = new System.Drawing.Size(75, 40);
            this.lblCalculate.TabIndex = 6;
            this.lblCalculate.Text = "Calculate Change";
            this.lblCalculate.UseVisualStyleBackColor = true;
            this.lblCalculate.Click += new System.EventHandler(this.lblCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(168, 105);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 143);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblCalculate);
            this.Controls.Add(this.lblGreatestChange);
            this.Controls.Add(this.lblLeastChange);
            this.Controls.Add(this.lblAverage);
            this.Controls.Add(this.lblLeastYear);
            this.Controls.Add(this.lblGreatestYear);
            this.Controls.Add(this.lblAnnualChange);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAnnualChange;
        private System.Windows.Forms.Label lblGreatestYear;
        private System.Windows.Forms.Label lblLeastYear;
        private System.Windows.Forms.Label lblAverage;
        private System.Windows.Forms.Label lblLeastChange;
        private System.Windows.Forms.Label lblGreatestChange;
        private System.Windows.Forms.Button lblCalculate;
        private System.Windows.Forms.Button btnExit;
    }
}

