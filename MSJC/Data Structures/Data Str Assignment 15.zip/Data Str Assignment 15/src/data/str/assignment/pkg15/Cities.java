/*
Daniel Meyer
0405182
5-16-16
Assignment 15
Graphs
 */
package data.str.assignment.pkg15;

import java.util.Iterator;
import java.util.LinkedList;

/*
Class: Cities
Author: Daniel Meyer
Description: Graphs cities using an adjacency list
Input: Strings to add to the graph as vertexes and edges
Output: The graph through depth first traversal
*/
public class Cities 
{
    private LinkedList<String>[] Vertex;
    private int Size;
    
    /*
    Function: Cities
    Author: Daniel Meyer
    Description: Default constructor that sets array size to 5
    Input: N/A
    Output: N/A
    */
    public Cities()
    {
        Size = 5;
        Vertex = new LinkedList[Size];
    }
    
    /*
    Function: Cities
    Author: Daniel Meyer
    Description: Overloaded constructor that sets array size to specified value
    Input: Int for array size
    Output: N/A
    */
    public Cities(int size)
    {
        Size = size;
        Vertex = new LinkedList[Size];
    }
    
    /*
    Function: addVertex
    Author: Daniel Meyer
    Description: Adds a vertex to the graph
    Input: String for the vertex
    Output: N/A
    */
    public void addVertex(String city)
    {
        int index = hash(city);
        
        while(Vertex[index] != null)
        {
            index++;
        }
        
        System.out.println(city + ": " + index);
        
        Vertex[index] = new LinkedList<String>();
        Vertex[index].add(city);
    }
    
    /*
    Function: addEdge
    Author: Daniel Meyer
    Description: Adds an edge to the specified vertex in the graph
    Input: String for the edge and string for the vertex (or source)
    Output: N/A
    */
    public void addEdge(String city, String source)
    {
        int index = 0;
        
        while(Vertex[index].getFirst() != source)
        {
            index++;
        }
        
        Vertex[index].addLast(city);
    }
    
    /*
    Function: hash
    Author: Daniel Meyer
    Description: Creates a hash value for the specified string
    Input: String to hash
    Output: Int for hashed value
    */
    private int hash(String data)
    {
        int location = 0;
        
        for(int i = 0; i < data.length(); i++)
        {
            location = (37 * location + data.charAt(i)) % Size;
        }
        
        location %= Size;
        
        if(location < 0)
        {
            location += Size;
        }
        
        return location;
    }
    
    /*
    Function: printGraph
    Author: Daniel Meyer
    Description: Prints the graph using depth first traversal
    Input: Int for index of vertex (or source) to start
    Output: N/A
    */
    public void printGraph(int source)
    {
        boolean visited[] = new boolean[Size];
        
        depthFirstTraversal(source, visited);
    }
    
    /*
    Function: depthFirstTraversal
    Author: Daniel Meyer
    Description: Prints the graph using depth first traversal
    Input: Int for index of vertex and boolean array for indexes visited
    Output: N/A
    */
    public void depthFirstTraversal(int source, boolean visited[])
    {
        visited[source] = true;
        System.out.println(Vertex[source]);
        
        Iterator<String> iter = Vertex[source].listIterator();
        int i;
        
        while(iter.hasNext())
        {
            i = Vertex[source].indexOf(iter.next());
            
            if(visited[i] != true)
            {
                depthFirstTraversal(i, visited);
            }
        }
    }
}
