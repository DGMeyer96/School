/*
Daniel Meyer
0405182
5-16-16
Assignment 15
Graphs
 */
package data.str.assignment.pkg15;

/*
Class: DataStrAssignment15
Author: Daniel Meyer
Description: Test class for Cities class
Input: N/A
Output: Depth first traversal of the graph
*/
public class DataStrAssignment15 
{

    /*
    Function: main
    Author: Daniel Meyer
    Description: Test function for the Cities class
    Input: N/A
    Output: Depth first traversal of the graph
    */
    public static void main(String[] args) 
    {
        Cities map = new Cities(6);
        
        String city3 = "Canyon Lake";
        String city1 = "Sun City";
        String city4 = "Lake Elsinore";
        String city5 = "Murietta";
        String city2 = "Menifee";
        String city0 = "Temecula";
        
        map.addVertex(city0);
        map.addVertex(city1);
        map.addVertex(city2);
        map.addVertex(city3);
        map.addVertex(city4);
        map.addVertex(city5);
        
        map.addEdge(city0, city1);
        map.addEdge(city0, city2);
        
        map.addEdge(city1, city0);
        map.addEdge(city1, city4);
        
        map.addEdge(city2, city0);
        map.addEdge(city2, city3);
        
        map.addEdge(city3, city2);
        map.addEdge(city3, city5);
        map.addEdge(city3, city4);
        
        map.addEdge(city4, city1);
        map.addEdge(city4, city3);
        map.addEdge(city4, city5);
        
        map.addEdge(city5, city3);
        map.addEdge(city5, city4);
        
        System.out.println("City 0: ");
        map.printGraph(0);
        System.out.println("City 1: ");
        map.printGraph(1);
        System.out.println("City 2: ");
        map.printGraph(2);
        System.out.println("City 3: ");
        map.printGraph(3);
        System.out.println("City 4: ");
        map.printGraph(4);
        System.out.println("City 5: ");
        map.printGraph(5);
    }
    
}
