/*
Daniel Meyer
0405182
3-15-16
Assignment 8
RPN Calculator
 */
package data.str.assignment.pkg8;

/*
Class: DoublyLinked
Author: Daniel Meyer 
Description: Doubly Linked List that hold generics
Inputs: Generic to add to, find, and remove from list
Outputs: DoublyLinked instances
*/
public class DoublyLinked<G>
{
    G Data;
    DoublyLinked<G> Head;
    DoublyLinked<G> Next;
    DoublyLinked<G> Prev;
    
    /*
    Function: DoublyLinked
    Author: Daniel Meyer
    Description: Sets class Head to null;
    Inputs: N/A
    Outputs: N/A
    */
    public DoublyLinked()
    {
        Head = null;
    }
    
    /*
    Function: moveFoward
    Author: Daniel Meyer
    Description: Moves the pointer foward to the next item in the list
    Inputs: N/A
    Outputs: N/A
    */
    public void moveFoward()
    {
        if(Head != null)
        {
            Head = Head.Next;
        }
    }
    
    /*
    Function: moveBackward
    Author: Daniel Meyer
    Description: Moves the pointer backward to the previous item in the list
    Inputs: N/A
    Outputs: N/A
    */
    public void moveBackward()
    {
        if(Head != null)
        {
            Head = Head.Prev;
        }
    }
    
    /*
    Function: addFront
    Author: Daniel Meyer
    Description: Adds a generic to the front of the list
    Inputs: Generic to add to the front of the list
    Outputs: N/A
    */
    public void addFront(G data)
    {
        if(Head == null)
        {
            Head = new DoublyLinked<G>();
            Head.Data = data;
            Head.Next = null;
            Head.Prev = null;
        }
        else
        {
            DoublyLinked<G> add = new DoublyLinked<G>();
            add.Data = data;
            add.Next = Head;
            Head = add;
            add.Prev = null;
        }
    }
    
    /*
    Function: addRear
    Author: Daniel Meyer
    Description: Adds a generic to the back of the list
    Inputs: Generic to add to the back of the list
    Outputs: N/A
    */
    public void addRear(G data)
    {
        if(Head == null)
        {
            Head = new DoublyLinked<G>();
            Head.Data = data;
            Head.Next = null;
            Head.Prev = null;
        }
        else
        {
            DoublyLinked<G> start = Head;
            
            while(start.Next != null)
            {
                start = start.Next;
            }
            
            DoublyLinked<G> add = new DoublyLinked<G>();
            add.Data = data;
            add.Next = null;
            
            start.Next = add;
            add.Prev = start;
        }
    }
    
    /*
    Function: insertAfter
    Author: Daniel Meyer
    Description: Inserts a generic after the specified item in the list
    Inputs: Generic to search for and a generic to add
    Outputs: N/A
    */
    public void insertAfter(G search, G data)
    {
        DoublyLinked<G> start = Head;
        
        while(!Head.Data.equals(search))
        {
            Head = Head.Next;
        }
        
        DoublyLinked<G> add = new DoublyLinked<G>();
        add.Data = data;
        
        add.Next = Head.Next;
        
        Head.Next.Prev = add;
        
        add.Prev = Head;
        Head.Next = add;
    }
    
    /*
    Function: delete
    Author: Daniel Meyer
    Description: Deletes the specified generic from the list
    Inputs: Generic to delete
    Outputs: N/A
    */
    public void delete(G search)
    {
        DoublyLinked<G> look = Head;
        
        while(!look.Data.equals(search))
        {
            look = look.Next;
        }
        
        look.Prev = look;
        look.Next = look.Next.Next;
    }
    
    /*
    Function: deleteFront
    Author: Dnaiel Meyer
    Description: Deletes the first generic in the list and returns it
    Inputs: N/A
    Outputs: An instance of the first item in the list
    */
    public DoublyLinked<G> deleteFront()
    {
        DoublyLinked<G> get = Head;
        /*
        if(Head.Next == null)
        {
            Head.Data = null;
            return null;
        }
        else
        {
            Head.Next.Prev = null;
        }
        */
        Head = Head.Next;
        
        return get;    
    }
    
    /*
    Function: find
    Author: Daniel Meyer
    Description: Searches for the generic in the list
    Inputs: Generic to search for
    Outputs: Instance of the found item in list
    */
    public DoublyLinked<G> find(G search)
    {
        DoublyLinked<G> look = Head;
        
        while(!look.Data.equals(search))
        {
            if(look.Next == null)
            {
                return null;
            }
            else
            {
                look = look.Next;
            }
        }
        
        return look;
    }
}
