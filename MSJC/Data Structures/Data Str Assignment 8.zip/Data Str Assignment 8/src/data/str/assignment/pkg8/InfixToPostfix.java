/*
Daniel Meyer
0405182
3-15-16
Assignment 8
RPN Calculator
 */
package data.str.assignment.pkg8;

import java.util.Scanner;

/*
Class: InfixToPostfix
Author: Daniel Meyer
Description: Converts infix notation to postfix notation
Input: Infix function as string
Output: Postfix function as string
*/
public class InfixToPostfix 
{
    /*
    Function: convert
    Author: Daniel Meyer
    Description: Converts an infix function to a postfix function
    Input: Infix function as string
    Output: Postfix function as string
    */
    public String convert(String infix)
    {
        Stack<Character> sChar = new Stack<Character>();
        StringBuilder postfix = new StringBuilder();
        
        for(int i = 0; i < infix.length(); i++)
        {
            if(infix.charAt(i) >= '0' && infix.charAt(i) <= '9')
            {
                postfix.append(infix.charAt(i));
            }
            else if(infix.charAt(i) == '(')
            {
                sChar.push(infix.charAt(i));
            }
            else if(infix.charAt(i) == ')')
            {
                while(sChar.peek() != '(')
                {
                    postfix.append(sChar.pop());
                }
                sChar.pop();
            }
            else if(infix.charAt(i) == '+' || infix.charAt(i) == '-' ||
                    infix.charAt(i) == '*' || infix.charAt(i) == '/')
            {
                if(sChar.stackSize() == 0)
                {
                    sChar.push(infix.charAt(i));
                }
                else if(!comparePrecedence(sChar.peek(), infix.charAt(i)))
                {
                    sChar.push(infix.charAt(i));
                }
                else
                {
                    while(sChar.stackSize() > 0 && comparePrecedence(sChar.peek(), infix.charAt(i)))
                    {
                        postfix.append(sChar.pop());
                    }
                    sChar.push(infix.charAt(i));
                }
            }
        }
        while(sChar.stackSize() > 0)
        {
            postfix.append(sChar.pop());
        }
        return postfix.toString();
    }
    
    /*
    Function: comparePrecedence
    Author: Daniel Meyer
    Description: Checks to see if order of operations is correct
    Input: The character on tp of stack and the next character
    Output: Boolean value representing if order of operations is ok
    */
    private static boolean comparePrecedence(char top, char c)
    {   
        if((top == '*' && c == '+') || (top == '*' && c == '-'))
        {
            return true;
        }
        else if((top == '/' && c == '+') || (top == '/' && c == '-'))
        {
            return true;
        }
        else if((top == '+' && c == '-') || (top == '-' && c == '+'))
        {
            return true;
        }
        else if((top == '*' && c == '/') || (top == '/' && c == '*'))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
