/*
Daniel Meyer
0405182
3-15-16
Assignment 8
RPN Calculator
 */
package data.str.assignment.pkg8;

/*
Class: RPNcalculator
Author: Daniel Meyer
Description: A Reverse Polish Notation Calculator
Input: String for the function to calculate
Output: Solution to the function
*/
public class RPNcalculator extends Stack<Double>
{
    /*
    Function: RPNcalculator
    Author: Daniel Meyer
    Description: Calculates function in postfix notation
    Input: String for the function
    Output: N/A
    */
    public RPNcalculator(String input)
    {
        char current;
        double num;
        double value1, value2;
        
        for(int i = 0; i < input.length(); i++)
        {
            current = input.charAt(i);
            
            if(current >= '0' && current <= '9')
            {
                num = Character.getNumericValue(current);
                super.push(num);
            }
            else if(current == '+')
            {
                value1 = super.peek();
                super.pop();
                value2 = super.peek();
                super.pop();
                add(value1, value2);
            }
            else if(current == '-')
            {
                value1 = super.peek();
                super.pop();
                value2 = super.peek();
                super.pop();
                sub(value1, value2);
            }
            else if(current == '*')
            {
                value1 = super.peek();
                super.pop();
                value2 = super.peek();
                super.pop();
                mul(value1, value2);
            }
            else if(current == '/')
            {
                value1 = super.peek();
                super.pop();
                value2 = super.peek();
                super.pop();
                div(value1, value2);
            }
        }
        //Checks size and contents of stack
        //super.printStack();
        //System.out.println("Size: " + super.stackSize());
    }
    
    /*
    Function:  add
    Author: Daniel Meyer
    Description: Gets the sum of the two values
    Input: Two doubles
    Output: Prints the sum of the two values
    */
    public void add(double value1, double value2)
    {
        double sum;
        sum = value1 + value2;
        System.out.println("Sum: " + sum);
        super.push(sum);
    }
    
    /*
    Function: sub
    Author: Daniel Meyer
    Description: Gets the difference of the two values
    Input: Two doubles
    Output: Prints the difference of the two values
    */
    public void sub(double value1, double value2)
    {
        double dif;
        dif = value1 - value2;
        System.out.println("Dif: " + dif);
        super.push(dif);
    }
    
    /*
    Function: mul
    Author: Daniel Meyer
    Description: Gets the product of the two values
    Input: Two doubles
    Output: Prints the product of the two values
    */
    public void mul(double value1, double value2)
    {
        double product;
        product = value1 * value2;
        System.out.println("Product: " + product);
        super.push(product);
    }
    
    /*
    Function: div
    Author: Daniel Meyer
    Description: Gets the quotient of the two values
    Input: Two doubles
    Output: Prints the quotient of the two values
    */
    public void div(double value1, double value2)
    {
        double quotient;
        quotient = value1 / value2;
        System.out.println("Quotient: " + quotient);
        super.push(quotient);
    }
}
