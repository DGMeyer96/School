/*
Daniel Meyer
0405182
3-15-16
Assignment 8
RPN Calculator
 */
package data.str.assignment.pkg8;

/*
Class: Queue
Author: Daniel Meyer
Description: Queue class that holds generics
Inputs: Generics to add to queue
Outputs: Generic on front of queue and each generic in queue
*/
public class Queue<G> extends DoublyLinked
{
    /*
    Function: enqueue
    Author: Daniel Meyer
    Description: Adds a generics to back of the queue
    Inputs: Generic to add to the back of the queue
    Outputs: N/A
    */
    public void enqueue(G data)
    {
        super.addRear(data);
    }
    
    /*
    Function: dequeue
    Author: Daniel Meyer
    Description: Removes and returns the generic at top of the queue
    Inputs: N/A
    Outputs: Generic removed from front of queue
    */
    public G dequeue()
    {
        //DoublyLinked<G> top = super.deleteFront();
        super.deleteFront();
        DoublyLinked<G> top = super.Head;
        
        if(top.Data == null)
        {
            return null;
        }
        else
        {
            return top.Data;
        }
    }
    
    /*
    Function: peek
    Author: Daniel Meyer
    Description: Returns generic at front of queue without removing it
    Inputs: N/A
    Outputs: Generic at ront of queue
    */
    public G peek()
    {
        DoublyLinked<G> data = super.Head;
        
        if(data.Data == null)
        {
            return null;
        }
        else
        {
            return data.Data;
        }
    }
    
    /*
    Function:
    Author:
    Description:
    Inputs:
    Outputs:
    */
    public void printQueue()
    {
        DoublyLinked<G> start = super.Head;
        
        System.out.println("Queue: ");
        
        while(start != null)
        {
            System.out.println(start.Data);
            start = start.Next;
        }
    }    
}
