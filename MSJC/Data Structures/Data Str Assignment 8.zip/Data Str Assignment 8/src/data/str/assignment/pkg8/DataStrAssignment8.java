/*
Daniel Meyer
0405182
3-15-16
Assignment 8
RPN Calculator
 */
package data.str.assignment.pkg8;

import java.util.Scanner;

/*
Class: DataStrAssignment8
Author: Daniel Meyer
Description: Test class for RPNcalculator and InfixToPostFix classes
Input: Strings for infix and postfix functions.
Output: Solutions to infix and postfix functions.
*/
public class DataStrAssignment8
{
    /*
    Function: main
    Author: Daniel Meyer
    Description: Gets solution to a postfix function and converts and infix function to postfix 
    Input: Strings for infix and postfix functions.
    Output: Solutions to infix and postfix functions.
    */
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        System.out.println("RPN Calculator:");
        String str = in.nextLine();
        RPNcalculator rpn = new RPNcalculator(str); 
        
        System.out.println("Infix to Postfix:");
        String str2 = in.nextLine();
        InfixToPostfix itp = new InfixToPostfix();
        System.out.println("Converted: " + itp.convert(str2)); //Converts to postfix
        RPNcalculator infix = new RPNcalculator(itp.convert(str2)); //Gets solution of convrsion
    }
    
}
