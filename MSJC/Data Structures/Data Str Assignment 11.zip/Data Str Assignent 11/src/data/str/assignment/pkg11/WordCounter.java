/*
Daniel Meyer
0405182
4-13-16
Assignment 11
Word Count
 */
package data.str.assignment.pkg11;

import java.util.ArrayList;

/*
Class: WordCounter
Author: Daniel Meyer
Description: Searches file for words and counts how many times they appear
Input: Array of strings for each lines in file
Output: Words and how many times they appear
*/
public class WordCounter extends AVLTree<String>
{
    ArrayList<String> wordList = new ArrayList<String>();
    
    /*
    Function: WordCounter
    Author: Daniel Meyer
    Description: Default contructor for WordCounter class
    Input: N/A
    Output: N/A
    */
    public WordCounter()
    {
        getList();
    }
    
    /*
    Function: countWords
    Author: Daniel Meyer
    Description: Counts how many times each word appears in file
    Input: N/A
    Output: N/A
    */
    public void countWords()
    {
        for(int i = 0; i < wordList.size(); i++)
        {
            String[] wordToken = wordList.get(i).split("\\s+ | "); //edit to remove white space and single letters
            
            for(String str : wordToken)
            {                
                if(!super.contains(str))
                {
                    super.insert(str);
                    super.retrieve(str).count++;
                }
                else
                {
                    super.retrieve(str).count++;
                }
            }
        }
    }
    
    /*
    Function: getLsit
    Author: Daniel Meyer
    Description: Gets each string in array list in FIleReader class and cleans them
    Input: N/A
    Output: Cleaned strings to array list in WordCounter class
    */
    private void getList()
    {
        FileReader fr = new FileReader();
        
        ArrayList<String> tempList = fr.getList();
        
        for(String str : tempList)
        {
            String clean = str.replaceAll("[^a-zA-Z]", " ");
            wordList.add(clean);
        }
    }
    
    /*
    Function: printList
    Author: Daniel Meyer
    Description: Prints each string in array list
    Input: N/A
    Output: Prints each string in array list
    */
    public void printList()
    {
        for(String str : wordList)
        {
            System.out.println(str);
        }
    }
}
