/*
Daniel Meyer
0405182
4-13-16
Assignment 11
Word Count
 */
package data.str.assignment.pkg11;

/*
Class: DataStrAssignment11
Author: Daniel Meyer
Description: Class to test WordCounter class
Input: N/A
Output: Words from file and how many times they appear
*/
public class DataStrAssignment11 
{
    
    /*
    Function: main
    Author: Daniel Meyer
    Description: Test function to test WordCounter class
    Input: N/A
    Output: Words from file and how many times they appear
    */
    public static void main(String[] args) 
    {
        WordCounter wc = new WordCounter();
        wc.printList();
        wc.countWords();
        
        wc.printAVLTree();
    }
    
}
