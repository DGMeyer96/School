/*
Daniel Meyer
0405182
3-28-16
Assignment 9
Palindromes
 */
package data.str.assignment.pkg9;

import java.io.*;

/*
Class: PalindromeReader
Author: Daniel Meyer
Description: Reads the file words.txt and checks if there are palindromes in it
Input: Strings from a text file
Output: Strings to a text file
*/
public class PalindromeReader extends Queue<String>
{
    /*
    Function: PalindromeReader
    Author: Daniel Meyer
    Description: Default Constructor
    Input: Strings from a text file
    Output: Strings to a text file
    */
    public PalindromeReader()
    {
        openFile();
        readFile();
        super.printQueue(); //checks the file was read correctly
        
        int size = super.sizeQueue();
        //System.out.println("Size of Queue: " + super.sizeQueue()); //checks size is correct
        
        for(int i = 0; i < size; i++)
        {
            if(isPalindrome() == true)
            {
                writeFile(super.peek());
            }
            super.moveRight();
        }
    }
    
    /*
    Function: isPalindrome
    Author: Daniel Meyer
    Description: Checks if the current String in the Queue is a palindrome
    Input: N/A
    Output: A true/false value if the string is a palindrome
    */
    private boolean isPalindrome()
    {
        String front = getFront();
        String back = getBack();
        
        //System.out.println("Front: " + getFront());
        //System.out.println("Back:  " + getBack());
        
        if(front.length() < back.length())
        {
            back = back.substring(0, back.length() - 1);
            
            if(front.equals(back))
            {
                return true;
            }
            
            return false;
        }
        else
        {
            if(front.equals(back))
            {
                return true;
            }
            
            return false;
        }
    }
    
    /*
    Function: getString
    Author: Daniel Meyer
    Description: Gets the next String in the Queue and removes all spaces
    Input: N/A
    Output: A String with its spaces removed
    */
    private String getString()
    {
        String str = super.peek();
        String cleaned = "";
        
        cleaned = str.replaceAll("[^a-z]", "");
        
        return cleaned;
    }
    
    /*
    Function: getFront
    Author: Daniel Meyer
    Description: Returns the first half of the String
    Input: N/A
    Output: The first half of the String
    */
    private String getFront()
    {
        String original = getString();
        String front = "";
        
        int length = original.length();
        int half = original.length() / 2;
        
        for(int i = 0; i < half; i++)
        {
            front += original.charAt(i);
        }
        
        return front;
    }
    
    /*
    Function: getBack
    Author: Daniel Meyer
    Description: Returns the second half of the String
    Input: N/A
    Output: The second half of the String
    */
    private String getBack()
    {
        String original = getString();
        String back = "";
        
        int length = original.length();
        int half = original.length() / 2;
        
        for(int i = length - 1; i >= half; i--)
        {
            back += original.charAt(i);
        }
        
        return back;
    }
    
    /*
    Function: openFile
    Author: Daniel Meyer
    Description: Checks the word.txt file can be opened
    Input: N/A
    Output: N/A
    */
    private void openFile()
    {
        try
        {
            FileInputStream fis = new FileInputStream("words.txt");
        }
        catch(FileNotFoundException fe)
        {
            System.out.println(fe.getMessage());
        }
    }
    
    /*
    Function: readFile
    Author: Daniel Meyer
    Description: Reads each line of the file and stores them in the Queue
    Input: Strings of each line in words.txt
    Output: N/A
    */
    private void readFile()
    {
        String input;
        
        try
        {
            FileReader fr = new FileReader("words.txt");
            BufferedReader br = new BufferedReader(fr);
            
            while((input = br.readLine()) != null)
            {
                super.enqueue(input.toLowerCase());
            }
            
            br.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println(e.getMessage());
        }
        catch(IOException ie)
        {
            System.out.println(ie.getMessage());
        }
    }
    
    /*
    Function: writeFile
    Author: Daniel Meyer
    Description: Creates a pal.txt file if it doesn't exist and writes a String to it
    Input: String to be written to the file
    Output: N/A
    */
    private void writeFile(String output)
    {
        BufferedWriter bw = null;
        FileWriter fw = null;
        
        try
        {
            File f = new File("pal.txt");
            
            if(!f.exists())
            {
                System.out.println("New File Created");
                f.createNewFile();
            }
            
            fw = new FileWriter(f, true); //true = append file
            bw = new BufferedWriter(fw);
            bw.write(output);
            bw.newLine();
            
            //System.out.println("Written to file: " + output); //shows string is written
            
            bw.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println(e.getMessage());
        }
        catch(IOException ie)
        {
            System.out.println(ie.getMessage());
        }
        finally
        {
            try
            {
                if(bw != null)
                {
                    bw.close();
                }              
            }
            catch(IOException ie)
            {
                System.out.println(ie.getMessage());
            }   
        }
    }
}
