/*
Daniel Meyer
0405182
3-28-16
Assignment 9
Palindromes
 */
package data.str.assignment.pkg9;

/*
Class: DataStrAssignment9
Author: Daniel Meyer
Description: Main class to test PalindromeReader class
Input: N/A
Output: N/A
*/
public class DataStrAssignment9 
{
    /*
    Function: main
    Author: Daniel Meyer
    Description: main function to test PalindromeReader class
    Input: N/A
    Output: N/A
    */
    public static void main(String[] args) 
    {
        PalindromeReader pr = new PalindromeReader();
    }
    
}
