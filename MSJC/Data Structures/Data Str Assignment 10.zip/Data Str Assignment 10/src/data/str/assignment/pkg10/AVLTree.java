/*
Daniel Meyer
0405182
4-5-16
Assignment 10
Binary Tree
 */
package data.str.assignment.pkg10;

/*
Class: AVLTree
Author: Daniel Meyer
Description: Class representing an AVL Tree
Input: Generics and Nodesto add and remove from the tree
Output: N/A
*/
public class AVLTree<G extends Comparable <G>> extends BinaryTree<G>
{      
    /*
    Function: rotateRight
    Author: Daniel Meyer
    Description: Rotates the current tree right
    Input: Root Node
    Output: New Root
    */
    private Node<G> rotateRight(Node<G> root)
    {
        Node p = root.Left;
        root.Left = p.Right;
        p.Right = root;
        return p;
    }
    
    /*
    Function: rotateWithRightChild
    Author: Daniel Meyer
    Description: Rotates the tree with the right child Node
    Input: Root Node
    Output: New root
    */
    private Node<G> rotateWithRightChild(Node<G> root)
    {
        Node p = root.Right;
        root.Right = p.Left;
        p.Left = root;
        
        root.height = Math.max( height(root.Left), height(root.Right)) + 1;
        p.height = Math.max(height(p.Right), root.height) + 1;
        
        return p;
    }
    
    /*
    Function: doubleWithRightChild
    Author: Daniel Meyer
    Description: Rotates the tree twice with the right child Node
    Input: Root Node
    Output: New root
    */
    private Node<G> doubleWithRightChild(Node<G> root)
    {
        root.Right = rotateLeft(root.Right);
        return rotateRight(root);
    }
    
    /*
    Function: rotateLeft
    Author: Daniel Meyer
    Description: Rotates the current tree left
    Input: Root Node
    Output: New Root
    */
    private Node<G> rotateLeft(Node<G> root)
    {
        Node p = root.Right;
        root.Right = p.Left;
        p.Left = root;
        return p;
    }
    
    /*
    Function: rotateWithLeftChild
    Author: Daniel Meyer
    Description: Rotates the tree with the left child Node
    Input: Root Node
    Output: New root
    */
    private Node<G> rotateWithLeftChild(Node<G> root)
    {
        Node p = root.Left;
        root.Left = p.Right;
        p.Right = root;
        
        root.height = Math.max( height(root.Left), height(root.Right)) + 1;
        p.height = Math.max(height(p.Left), root.height) + 1;
        
        return p;
    }
    
    /*
    Function: doubleWithLeftChild
    Author: Daniel Meyer
    Description: Rotates the tree twice with the left child Node
    Input: Root Node
    Output: New root
    */
    private Node<G> doubleWithLeftChild(Node<G> root)
    {
        root.Left = rotateRight(root.Left);
        return rotateLeft(root);
    }
    
    /*
    Function: insert
    Author: Daniel Meyer
    Description: Accessor for the insert function in the BinaryTree class
    Input: Generic to add and Node to balance
    Output: Balanced Node
    */
    public Node<G> insert(G data, Node<G> t)
    {
        super.insert(data);
        
        return balance(t);
    }
    
    /*
    Function: remove
    Author: Daniel Meyer
    Description: Accessor for the remove function in the BinaryTree class
    Input: Generic to remove and Node to balance
    Output: Balanced Node
    */
    public Node<G> remove(G data, Node<G> t)
    {
        super.remove(data);
        
        return balance(t);
    }
    
    /*
    Function: balance
    Author: Daniel Meyer
    Description: Rebalances the AVL Tree and its sub trees
    Input: Root Node
    Output: New root Node
    */
    private Node<G> balance(Node<G> t)
    {
        if(t == null)
        {
            return t;
        }
        else if(height(t.Left) - height(t.Right) > 1)
        {
            if(height(t.Left.Left) >= height(t.Left.Right))
            {
                t = rotateLeft(t);
            }
            else
            {
                t = doubleWithLeftChild(t);
            }
        }
        else if(height(t.Right) - height(t.Left) > 1)
        {
            if(height(t.Right.Right) >= height(t.Right.Left))
            {
                t = rotateRight(t);
            }
            else
            {
                t = doubleWithRightChild(t);
            }
        }
        
        t.height = Math.max(height(t.Left), height(t.Right)) + 1;
        
        return t;
    }
    
    /*
    Function: height
    Author: Daniel Meyer
    Description: Returns the height of the tree
    Input: Root Node
    Output: Height as an int
    */
    private int height(Node<G> t)
    {
        return t == null ? -1 : t.height;
    }
    
    /*
    Function: printAVLTree
    Author: Daniel Meyer
    Description: Accessor for printTree cuntion in the BinaryTree class
    Input: N/A
    Output: N/A
    */
    public void printAVLTree()
    {
        super.printTree();
    }
}
