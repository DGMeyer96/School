/*
Daniel Meyer
0405182
4-5-16
Assignment 10
Binary Tree
 */
package data.str.assignment.pkg10;

/*
Function: DataStrAssignment10
Author: Daniel Meyer
Description: Test Class for BinaryTree and AVLTree classes
Input: Strings to add to the Trees
Output: Contents of AVLTree to console
*/
public class DataStrAssignment10 
{
    /*
    Function: main
    Author: Daniel Meyer
    Description: Test function for BInaryTree and AVL Tree classes
    Input: Strings to add to the Trees
    Output: Contents of AVLTree to console
    */
    public static void main(String[] args) 
    {
        AVLTree<String> avl = new AVLTree<String>();
        
        avl.insert("Hello World");
        avl.insert("This is a test");
        avl.insert("123");
        avl.insert("abc");
        avl.insert("End of test");
        
        avl.printAVLTree();
        avl.remove("This is a test");
        
        System.out.println("Removed: 123");
        avl.printAVLTree();
    }
    
}
