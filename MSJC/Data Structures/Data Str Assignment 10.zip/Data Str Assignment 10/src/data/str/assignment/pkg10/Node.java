/*
Daniel Meyer
0405182
4-5-16
Assignment 10
Binary Tree
 */
package data.str.assignment.pkg10;

/*
Class: Node
Author: Daniel Meyer
Description: Class for Nodes to hold data in a tree
Input: Data to store in the node
Output: N/A
*/
public class Node<G> 
{
    G Data;
        
    Node<G> Left;
    Node<G> Right;
        
    int height;
    
    /*
    Function: Node
    Author: Daniel Meyer
    Description: Constructor that sets data
    Input: Generic to set as data
    Output: N/A
    */
    public Node(G data)
    {
        this.Data = data;
    }
    
    /*
    Function: Node
    Author: Daniel Meyer
    Description: Constructor that sets data and left and right Nodes
    Input: Generic to add and left and right Nodes
    Output: N/A
    */
    public Node(G data, Node<G> r, Node<G> l)
    {
        this.Left = l;
        this.Right = r;
        this.Data = data;
    }
}
