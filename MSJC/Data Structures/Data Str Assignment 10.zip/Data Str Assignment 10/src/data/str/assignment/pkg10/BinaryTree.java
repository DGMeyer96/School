/*
Daniel Meyer
0405182
4-5-16
Assignment 10
Binary Tree
 */
package data.str.assignment.pkg10;

/*
Class: BinaryTree
Author: Daniel Meyer
Description: Class representing a Binary Tree
Input: Generics to add and remove from tree
Output: N/A
*/
public class BinaryTree<G extends Comparable<G>>
{   
    Node<G> Root;
    private int sizeLeft = 0;
    private int sizeRight = 0;
    
    /*
    Function: BinaryTree
    Author: Daniel Meyer
    Description: Default Construct for the class
    Input: N/A
    Output: N/A
    */
    public BinaryTree()
    {
        Root = null;
    }
    
    /*
    Function: insert
    Author: Daniel Meyer
    Description: Adds a Generic to the tree
    Input: Generic to add and current node
    Output: N/A
    */
    private void insert(G data, Node<G> n) //Can't use '>' or '<', needs to extend comparable
    {
        if(Root == null)
        {
            Root = new Node<G>(data);
        }
        else if((data).compareTo(n.Data) < 0) //Less than
        {
            if(n.Left != null)
            {
                insert(data, n.Left);
            }
            else
            {
                n.Left = new Node(data);
            }
        }
        else if((data).compareTo(n.Data) > 0) //Greater than
        {
            if(n.Right != null)
            {
                insert(data, n.Right);
            }
            else
            {
                n.Right = new Node(data);
            }
        }
    }
    
    /*
    Function: insert
    Author: Daniel Meyer
    Description: Accessor for insert function
    Input: Generic to add
    Output: N/A
    */
    public void insert(G data)
    {
        this.insert(data, this.Root);
    }
    
    /*
    Function: remove
    Author: Daniel Meyer
    Description: Removes Generic from tree
    Input: Data to remove and current Node
    Output: New Node
    */
    private Node<G> remove(G data, Node<G> n)
    {
        if(this.Root == null)
        {
            return n;
        }
        else if((data).compareTo(n.Data) < 0)
        {
            n.Left = this.remove(data, n.Left);
        }
        else if((data).compareTo(n.Data) > 0)
        {
            n.Right = this.remove(data, n.Right);
        }
        else if(n.Left != null && n.Right != null)
        {
            n.Data = findMin(n.Right);
            remove(n.Data, n.Right);
        }
        else
        {
            n = (n.Left != null) ? n.Left : n.Right;
        }
        
        return n;
    }
    
    /*
    Function: remove
    Author: Daniel Meyer
    Description: Accessor for remove function
    Input: Data to remove
    Output: N/A
    */
    public void remove(G data)
    {
        this.remove(data, this.Root);
    }
    
    /*
    Function: contains
    Author: Daniel Meyer
    Description: Checks if the tree contains specified Generic
    Input: Generic to search for and current Node
    Output: Boolean for whether or not the generic was found
    */
    private boolean contains(G data, Node<G> n)
    {
        if(n == null)
        {
            return false;
        }
        else if((data).compareTo(n.Data) < 0)
        {
            return contains(data, n.Left);
        }
        else if((data).compareTo(n.Data) > 0)
        {
            return contains(data, n.Right);
        }
        else
        {
            return true;
        }
    }
    
    /*
    Function: contains
    Author: Daniel Meyer
    Description: Accessor for contains function
    Input: Generic to search for
    Output: Boolean for whether or not the generic was found
    */
    public boolean contains(G data)
    {
        return this.contains(data, this.Root);
    }
    
    /*
    Function: findMin
    Author: Daniel Meyer
    Description: Searches tree for the smallest generic
    Input: Root Node
    Output: Smallest generic in tree
    */
    private G findMin(Node<G> n)
    {
        if(n.Left == null)
        {
            return n.Data;
        }
        else
        {
            return findMin(n.Left);
        }
    }
    
    /*
    Function: findMin  
    Author: Daniel Meyer
    Description: Accessor for findMin function
    Input: N/A
    Output: Smallest generic in tree
    */
    public G findMin()
    {
        return this.findMin(this.Root);
    }
    
    /*
    Function: findMax
    Author: Daniel Meyer
    Description: Searches tree for largest generic
    Input: Root Node
    Output: Largest generic in the tree
    */
    private G findMax(Node<G> n)
    {
        if(n.Right == null)
        {
            return n.Data;
        }
        else
        {
            return findMax(n.Right);
        }
    }
    
    /*
    Function: findMax
    Author: Daniel Meyer
    Description: Accessor for findMAx function
    Input: N/A
    Output: Largest generic in the tree
    */
    public G findMax()
    {
        return this.findMax(this.Root);
    }
    
    /*
    Function: isEmpty
    Author: Daniel Meyer
    Description: Checks to see if the tree is empty
    Input: N/A
    Output: Boolean for whether or not the tree is empty
    */
    public boolean isEmpty()
    {
        return this.Root == null;
    }
    
    /*
    Function: printTree
    Author: Daniel Meyer
    Description: Prints the conents of the tree
    Input: N/A
    Output: N/A
    */
    private void printTree(Node<G> n)
    {
        if(n != null)
        {
            System.out.println(n.Data);
            this.printTree(n.Left);
            this.printTree(n.Right);
        }
    }
    
    /*
    Function: printTree
    Author: Daniel Meyer
    Description: Accessor funtion for printTree
    Input: N/A
    Output: N/A
    */
    public void printTree()
    {
        this.printTree(this.Root);
    }
}
