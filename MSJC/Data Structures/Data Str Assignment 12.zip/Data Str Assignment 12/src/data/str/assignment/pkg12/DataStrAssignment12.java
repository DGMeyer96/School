/*
Daniel Meyer
0405182
4-26-16
Assignment 12
Hash Table
 */
package data.str.assignment.pkg12;

/*
Class: DataStrAssignment12
Author: Daniel Meyer
Description: Test class for HashTable class
Input: Doubles to add to hash table and to search for
Output: Number of times searched for value was found and hash table
*/
public class DataStrAssignment12 
{
    /*
    Function: main
    Author: Daniel Meyer
    Description: Test function for HashTable class
    Input: Doubles to add to hash table and to search for
    Output: Number of times searched for value was found and hash table
    */
    public static void main(String[] args) 
    {
        double value = 9999.8;
        
        HashTable ht = new HashTable();
        
        
        ht.hash(value);
        ht.hash(123.456);
        ht.hash(123.456);
        ht.hash(124.456);
        ht.hash(123.596);
        ht.hash(135.79);
        ht.hash(246.8);
        ht.hash(value);
        ht.hash(value);
        ht.hash(value);
        ht.hash(value);
          
        
        ht.printTable();
        System.out.println(ht.search(value) + "\n");
        
        ht.resize(60);
        
        ht.remove(value);
        ht.printTable();
        System.out.println(ht.search(value) + "\n");
    }
    
}
