/*
Daniel Meyer
0405182
4-26-16
Assignment 12
Hash Table
 */
package data.str.assignment.pkg12;

/*
Class: HashTable
Author: Daniel Meyer
Description: Hash Table that 
Input: Int for array size and double to hash and search for
Output: Number of times searched for double was found
*/
public class HashTable
{
    private int tableSize;
    private Node[] table;
    
    /*
    Function: HashTable
    Author: Daniel Meyer
    Description: Default Constructor that sets table size to 50
    Input: N/A
    Output: N/A
    */
    public HashTable()
    {
        this.tableSize = 50;
        this.table = new Node[this.tableSize];
    }
    
    /*
    Function: HashTable
    Author: Daniel Meyer
    Description: Constructor that sets table size to specified value
    Input: Int for table size
    Output: N/A
    */
    public HashTable(int tableSize)
    {
        this.tableSize = tableSize;
        this.table = new Node[this.tableSize];
    }
    
    /*
    Function: resize
    Author: Daniel Meyer
    Description: Resizes the array 
    Input: Int for new table size
    Output: N/A
    */
    public void resize(int tableSize)
    {
        Node[] temp = this.table;
        
        this.tableSize = tableSize;
        this.table = new Node[this.tableSize];
        
        for(int i = 0; i < temp.length; i++)
        {
            this.table[i] = temp[i];
        }
    }
    
    /*
    Function: hash
    Author: Daniel Meyer
    Description: Hashes a double and adds it to hash table
    Input: Double to hash and add to hash table
    Output: N/A
    */
    public void hash(double value)
    {
        int index;

        index = Double.hashCode(value) % tableSize; //gets hashCode value for double as an int
        
        if(index < 0) //accounts for overflow that would result in a negative
        {
            index += tableSize;
        }
        
        System.out.println("Index for " + value + ": " + index);
        
        Node n = new Node(value); //Node to add
        
        if(table[index] == null) //Checks if the index is empty
        {
            table[index] = n;
        }
        else
        {
            n.Next = table[index];
            table[index] = n;
        }
    }
    
    /*
    Function: search
    Author: Daniel Meyer
    Description: Searches for double and returns the number of times it was found
    Input: Double to search for
    Output: Number of times the double was found
    */
    public int search(double value)
    {
        int occurences = 0;
        int index = Double.hashCode(value) % tableSize; 
        
        if(table[index] != null) //searches for the index where the value would be stored
        {
            occurences++; //increments how many times it is found
            
            while(table[index].Next != null)
            {
                occurences++; //increments if multiples are in the same index
                table[index] = table[index].Next;
            }
        }
        
        return occurences;
    }
    
    /*
    Function: remove
    Author: Daniel Meyer
    Description: Removes all specified doubles
    Input: Double to find and remove
    Output: N/A
    */
    public void remove(double value)
    {
        int index = Double.hashCode(value) % tableSize;
        
        if(table[index] != null)
        {
            while(table[index].Next != null)
            {
                table[index] = table[index].Next;
            }
            
            table[index].Next = null;
            table[index] = null;
        }
    }
    
    /*
    Function: printTable
    Author: Daniel Meyer
    Description: Prints the hash table
    Input: N/A
    Output: N/A
    */
    public void printTable()
    {
        for(int i = 0; i < tableSize; i++)
        {
            System.out.println("Index " + i + ":");
            Node current = table[i];
            
            while(current != null)
            {
                System.out.println(current.Data);
                current = current.Next;
            }
        }
    }
}
