/*
Daniel Meyer
0405182
4-26-16
Assignment 12
Hash Table
 */
package data.str.assignment.pkg12;

/*
Class: Node
Author: Daniel Meyer
Description: Linked List node that stores data for hash table
Input: Double for data
Output: N/A
*/
public class Node 
{
    double Data;
    
    Node Next;
    
    /*
    Function: Node
    Author: Daniel Meyer
    Description: Constructor that sets data to specified double value
    Input: Double to set as data
    Output: N/A
    */
    public Node(double data)
    {
        this.Data = data;
        this.Next = null;
    }
}
