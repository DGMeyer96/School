/*
Daniel Meyer
0405182
2-18-16
Generics and Templates
 */
package data.str.assignment.pkg5;

/*
Class: PairException
Author: Daniel Meyer
Description: Handles exceptions for the Pair and PairList classes
Inputs: N/A
Outputs: String containg the error message
*/

/*
Function: PairException
Author: Daniel Meyer
Description: Sets the error message when the index is out of bounds
Inputs: An int for the index that is out of bounds
Outputs: N/A
*/

/*
Function: PairException
Author: Daniel Meyer
Description: Sets the error message when the searched for Pair doesn't exist
Inputs: Pair to search for
Outputs: N/A
*/

public class PairException extends Exception
{
    private String error;
    
    public PairException(int index)
    {
        error = "No Pair at index: " + index;
    }
    
    public PairException(Pair p)
    {
        error = "That Pair does not exist.";
    } 
}
