/*
Daniel Meyer
0405182
2-18-16
Generics and Templates
 */
package data.str.assignment.pkg5;

/*
Class: PairList
Author: Daniel Meyer
Description: Holds an arraylist of Pairs
Inputs: N/A
Outputs: ArrayList of Pairs, searched for Pair, ArrayList size, searched for first and second items
*/

/*
Function: PairList
Author: Daniel Meyer
Description: Default contructor that adds Pair f,s to the arraylist
Inputs: N/A
Outputs: N/A
*/

/*
Function: PairList
Author: Daniel Meyer
Description: Overloaded constructor creating a Pair from f,s and adding it to the arraylist
Inputs: f, s for a new Pair to add to the arraylist
Outputs: N/A
*/

/*
Function: PairList
Author: Daniel Meyer
Description: Overloaded constructor adding the Pair to the arraylist
Inputs: Pair to be added to the arraylist
Outputs: N/A
*/

/*
Function: addPair
Author: Daniel Meyer
Description: Adds a Pair to the arraylist
Inputs: Pair to be added to the arraylist
Outputs: N/A
*/

/*
Function: removePair
Author: Daniel Meyer
Description: Removes the Pair at the given index
Inputs: Index for the Pair to be removed
Outputs: N/A
*/

/*
Function: searchPair
Author: Daniel Meyer
Description: Searches for the Pair in the arraylist
Inputs: Pair to search for
Outputs: N/A
*/

/*
Function: searchFirst
Author: Daniel Meyer
Description: Searches for the first item in a Pair in the arraylist
Inputs: First item f to search for
Outputs: N/A
*/

/*
Function: searchSecond
Author: Daniel Meyer
Description: Searches for the second item in a Pair in the arraylist
Inputs: Second item s to search for
Outputs: N/A
*/

/*
Function: getListSize
Author: Daniel Meyer
Description: Returns the size of the arraylist
Inputs: N/A
Outputs: Size of the arraylist as an int
*/

/*
Function: getList
Author: Daniel Meyer
Description: Returns the arraylist of Pairs
Inputs: N/A
Outputs: The arraylist of Pairs
*/

/*
Function: printList
Author: Daniel Meyer
Description: Prints out the arraylist to the console
Inputs: N/A
Outputs: The arraylist of Pairs
*/

import java.util.ArrayList;
import java.util.Iterator;

public class PairList<F, S> 
{
    private ArrayList<Pair> pList = new ArrayList<Pair>();
    
    public PairList()
    {
        Pair p = new Pair('f', 's');
        addPair(p);
    }
    
    public PairList(F f, S s)
    {
        Pair p = new Pair(f,s);
        addPair(p);
    }
    
    
    public PairList(Pair p)
    {
        addPair(p);
    }
    
    public void addPair(Pair p)
    {
        pList.add(p);
    }
    
    public void removePair(int index) throws PairException
    {
        if(index <= pList.size())
        {
            pList.remove(index - 1);
        }
        else
        {
            throw new PairException(index);
        }
    }
    
    public Pair searchPair(Pair p) throws PairException
    {
        for(Pair find : pList)
        {
            if(p.equals(find))
            {
                return find;
            }
        }   
        throw new PairException(p);
    }
    
    public S searchFirst(F f)
    {
        Iterator<Pair> pIter = pList.iterator();
        
        while(pIter.hasNext())
        {
            Pair p = pIter.next();
            
            if(f.equals(p.getFirst()))
            {
                return (S) p.getSecond();
            }
        }
        return null;
    }
    
    public F searchSecond(S s)
    {
        Iterator<Pair> pIter = pList.iterator();
        
        while(pIter.hasNext())
        {
            Pair p = pIter.next();
            
            if(s.equals(p.getFirst()))
            {
                return (F) p.getFirst();
            }
        }
        return null;
    }
    
    public int getListSize()
    {
        return pList.size();
    }
    
    public ArrayList<Pair> getList()
    {
        return pList;
    }
    
    public void printList()
    {
        int i = 1;
        for(Pair next : pList)
        {       
            System.out.println("Pair " + i + ": " + next.getFirst() + " , " + next.getSecond());
            i++;
        }
    }
}
