/*
Daniel Meyer
0405182
2-18-16
Generics and Templates
 */
package data.str.assignment.pkg5;

/*
Class: DataStrAssignment5
Author: Daniel Meyer
Description: Class to test Pair and PairList classes
Inputs: N/A
Outputs: Items in Pair and Pairs in PairList
*/

/*
Function: main
Author: Daniel Meyer
Description: Main function for testing Pair and PairList classes
Inputs: Strings for Pair
Outputs: Items in Pair and Pairs in PairList
*/

import java.util.Scanner;
import java.util.ArrayList;

public class DataStrAssignment5 
{
    
    public static void main(String[] args) throws PairException 
    {
        Scanner in = new Scanner(System.in);
        
        ArrayList<Pair> al;
        String item1;
        String item2;
        
        PairList pl = new PairList();

        for(int i = 0; i < 5; i++)
        {           
            System.out.println("Enter your first item.");
            item1 = in.nextLine();
        
            System.out.println("Enter your second item.");
            item2 = in.nextLine();
            
            Pair<String,String> p = new Pair<>(item1, item2);
            p = new Pair<String,String>(item1, item2);
            System.out.println("Your first item: " + p.getFirst());
            System.out.println("Your second item: " + p.getSecond());
            
            pl.addPair(p);
            al = pl.getList();
            
            System.out.println("Current List:");
            pl.printList();
        }
        
        System.out.println("Enter the first item in the Pair to search for.");
        System.out.println("Found: " + in.nextLine() + " , " + pl.searchFirst(in.nextLine()));
        
        System.out.println("Enter the second item in the Pair to search for.");
        System.out.println("Found: "  + pl.searchSecond(in.nextLine()) + " , " + in.nextLine());
        
        System.out.println("Enter the index # of the item you want to remove.");
        pl.removePair(in.nextInt());
        System.out.println("Current List:");
        pl.printList();
    }
    
}
