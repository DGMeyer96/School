/*
Daniel Meyer
0405182
2-18-16
Generics and Templates
 */
package data.str.assignment.pkg5;

/*
Class: Pair
Author: Daniel Meyer
Description: Holds a pair of objects
Inputs: N/A
Outputs: First and Second objects
*/

/*
Function: Pair
Author: Daniel Meyer
Description: Constructor that takes two objects as a Pair
Inputs: Object F for first item and Object S for second item
Outputs: N/A
*/

/*
Function: getFirst
Author: Daniel Meyer
Description: Returns first item in the Pair
Inputs: N/A
Outputs: Object f, the first item
*/

/*
Function: getSecond
Author: Daniel Meyer
Description: Returns second item in the Pair
Inputs: N/A
Outputs: Object s, the second item
*/

/*
Function: setFirst
Author: Daniel Meyer
Description: Sets the data section, first, to the input
Inputs: Object f, the first item
Outputs: N/A
*/

/*
Function: setSecond
Author: Daniel Meyer
Description: Sets the data section, second, to the input
Inputs: Object s, the second item
Outputs: N/A
*/

public class Pair<F, S> 
{
    private F first;
    private S second;
    
    public Pair(F f, S s)
    {
        setFirst(f);
        setSecond(s);
    }
    
    public F getFirst()
    {
        return first;
    }
    
    public S getSecond()
    {
        return second;
    }
    
    public void setFirst(F f)
    {
        first = f;
    }
    
    public void setSecond(S s)
    {
        second = s;
    }
}
