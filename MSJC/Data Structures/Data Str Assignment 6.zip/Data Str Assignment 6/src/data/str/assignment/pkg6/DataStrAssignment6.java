/*
Daniel Meyer
0405182
3-1-16
Assignment 6
Linked Lists
 */
package data.str.assignment.pkg6;


/*
Class: DataStrAssignment6
Author: Daniel Meyer
Description: Class that tests the Linked and PairList classes
Input: N/A
Output: Pairs of Strings added to the Linked List
*/
public class DataStrAssignment6 
{
    /*
    Function: main
    Author: Daniel Meyer
    Description: Function to test the Linked and PairList classes       
    Input: N/A
    Output: Pairs of Strings added to the Linked List
    */
    public static void main(String[] args) 
    {
        //Creates 3 instances of PairList containing pairs of generics
        PairList<String, String> p1 = new PairList<String, String>("Hello", "World");
        PairList<String, String> p2 = new PairList<String, String>("abc", "def");
        PairList<String, String> p3 = new PairList<String, String>("123", "456");
        
        //Adds pair "p1" to the front of the list
        p1.addFront(p1);
        
        //Adds a pair "p2" to the back of the list
        p1.addRear(p2);
        
        //Prints the list to check that the two pairs are added
        p1.printPairs();
        
        //Inserts the pair "p3" after pair "p1"
        p1.insertPair(p1, p3);
        
        //Prints the list to check that the pair was inserted
        p1.printPairs();
        
        //Removes the pair "p3" from the list
        p1.removePair(p3);
        
        //Prints the list to check that the pair was removed
        p1.printPairs();
        
        //Searches for pair "p1" and prints if it was found or not
        System.out.println(p1.findPair(p1));
    }  
}
