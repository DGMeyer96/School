/*
Daniel Meyer
0405182
3-1-16
Assignment 6
Linked Lists
 */
package data.str.assignment.pkg6;

/*
Class: PairList
Author: Daniel Meyer
Description: Creates a list of generic pairs that is held in a Linked List
Input: Generic pairs and first and second items in generic pair
Output: Generics
*/
public class PairList<F,S> extends Linked
{
    private F first;
    private S second;
    
    /*
    Function: PairList
    Author: Daniel Meyer
    Description: Creates a pair of generics
    Input: First generic for pair and second generic for pair
    Output: N/A
    */
    public PairList(F f, S s)
    {
        first = f;
        second = s;
    }
    
    /*
    Function: getFirst
    Author: Daniel Meyer
    Description: Returns the first half of the generic pair
    Input: N/A
    Output: First half of the generic pair
    */
    public F getFirst()
    {
        return first;
    }
    
    /*
    Function: getSecond
    Author: Daniel Meyer
    Description: Returns the second half of the generic pair
    Input: N/A
    Output: Second half of the generic pair
    */
    public S getSecond()
    {
        return second;
    }
    
    /*
    Function: addPairFront
    Author: Daniel Meyer
    Description: Adds a generic to the front of the Linked List
    Input: Generic to add
    Output: N/A
    */
    public void addPairFront(PairList p)
    {
        super.addFront(p);
    }
    
    /*
    Function: addPairRear
    Author: Daniel Meyer
    Description: Adds a generic to the back of the Linked List
    Input: Generic to add
    Output: N/A
    */
    public void addPairRear(PairList p)
    {
        super.addRear(p);
    }
    
    /*
    Function: insertPair
    Author: Daniel Meyer
    Description: Adds a generic after the searched for generic
    Input: Generic to insert after and generic to add
    Output: N/A
    */
    public void insertPair(PairList search, PairList p)
    {
        super.insertAfter(search, p);
    }
    
    /*
    Function: removePair
    Author: Daniel Meyer
    Description: Removes generic from Linked List
    Input: Generic to search for and remove
    Output: N/A
    */
    public void removePair(PairList search)
    {
        super.delete(search);
    }
    
    /*
    Function: findPair
    Author: Daniel Meyer
    Description: Searches for specified generic and returns if found else returns null
    Input: Generic to search for
    Output: String of generic if found
    */
    public String findPair(PairList search)
    {
        String str;
        Linked<PairList> found;
        
        if(super.find(search) == null)
        {
            str = "Unable to find: " + search.getFirst() + " , " + search.getSecond();
            return str;
        }
        else
        {
            found = super.find(search);
            return str = "Found: " + found.Data.getFirst() + " , " + found.Data.getSecond();
        }
    }
    
    /*
    Function: printPairs
    Author: Daniel Meyer
    Description: Prints the generic stored in the Linked List
    Input: N/A
    Output: Generics
    */
    public void printPairs()
    {
        Linked<PairList> start = super.Head;
        
        System.out.println("Linked: ");
        
        while(start != null)
        {
            System.out.println(start.Data.getFirst() + " , " + start.Data.getSecond());
            start = start.Next;
        }
    }
}
