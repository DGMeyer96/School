/*
Daniel Meyer
0405182
3-1-16
Assignment 6
Linked Lists
 */
package data.str.assignment.pkg6;

/*
Class: Linked
Author: Daniel Meyer
Description: A Linked List that holds generics.
Input: Generics for data to add and to search for.
Output: Generics
*/
public class Linked<PairList>
{
    PairList Data;
    Linked<PairList> Next;
    Linked<PairList> Head;
    
    /*
    Function: Linked
    Author: Daniel Meyer
    Description: Constructor that sets the front of the list to null.
    Input: N/A
    Output: N/A
    */
    public Linked()
    {
        Head = null;
    }
    
    /*
    Function: addFront
    Author: Daniel Meyer
    Description: Adds a generic to the front of the Linked List
    Input: Generic to add to the front of the list
    Output: N/A
    */
    public void addFront(PairList data)
    {
        Linked<PairList> add = new Linked<PairList>();
        add.Data = data;
        add.Next = Head;
        Head = add;
    }
    
    /*
    Function: addRear
    Author: Daniel Meyer
    Description: Adds a generic to the back of the Linked List
    Input: Generic to add to the back of the list
    Output: N/A
    */
    public void addRear(PairList data)
    {
        if(Head == null)
        {
            Head = new Linked<PairList>();
            Head.Data = data;
            Head.Next = null;
        }
        else
        {
            while(Head.Next != null)
            {
                Head = Head.Next;
            }
            
            Linked<PairList> add = new Linked<PairList>();
            add.Data = data;
            add.Next = null;
            
            Head.Next = add;
        }
    }
    
    /*
    Function: insertAfter
    Author: Daniel Meyer
    Description: Inserts a generic after the specified generic
    Input: Generic to insert after and a generic to add
    Output: N/A
    */
    public void insertAfter(PairList search, PairList data)
    {
        while(!Head.Data.equals(search))
        {
            Head = Head.Next;
        }
        
        Linked<PairList> add = new Linked<PairList>();
        add.Data = data;
        
        add.Next = Head.Next;
        
        Head.Next = add;
    }
    
    /*
    Function: delete
    Author: Daniel Meyer
    Description: Searches for and removes the generic
    Input: Generic to search for and remove
    Output: N/A
    */
    public void delete(PairList search)
    {
        while(!Head.Next.Data.equals(search))
        {
            Head = Head.Next;
        }
        
        Head.Next = Head.Next.Next;
    }
    
    /*
    Function: find
    Author: Daniel Meyer
    Description: Searches for and returns the generic if found else returns null
    Input: Generic to search for
    Output: Generic if found else null if generic doesn't exist
    */
    public Linked<PairList> find(PairList search)
    {
        Linked<PairList> look = Head;
        
        while(!Head.Data.equals(search))
        {
            if(Head.Next == null)
            {
                return null;
            }
            else
            {
               Head = Head.Next; 
            }
        }
        
        return Head;
    }
}
