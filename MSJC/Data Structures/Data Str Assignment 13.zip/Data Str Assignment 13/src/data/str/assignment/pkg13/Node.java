/*
Daniel Meyer
0405182
5-2-16
Assignment 13
Application of the Hash Table
 */
package data.str.assignment.pkg13;

/*
Class: Node
Author: Daniel Meyer
Description: Linked List node that stores data for hash table
Input: Double for data, long for data
Output: N/A
*/
public class Node 
{
    double Data;
    long Number;
    String Name;
    int offset = 0;
    
    Node Next;
    
    /*
    Function: Node
    Author: Daniel Meyer
    Description: Constructor that sets data to specified double value
    Input: Double to set as data
    Output: N/A
    */
    public Node(double data)
    {
        this.Data = data;
        this.Next = null;
    }
    
    /*
    Function: Node
    Author: Daniel Meyer
    Description: Constructor that sets data to specified long value
    Input: Long to set as data
    Output: N/A
    */
    public Node(long data, String name)
    {
        this.Number = data;
        this.Name = name;
        this.Next = null;
    }
}
