/*
Daniel Meyer
0405182
5-2-16
Assignment 13
Application of the Hash Table
 */
package data.str.assignment.pkg13;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/*
Class: FileReader
Author: Daniel Meyer
Description: Reads each line in file and stores them in array list as strings
Input: Each line in array list
Output: N/A
*/
public class FileReader 
{
    ArrayList<String> strList = new ArrayList<String>();
    
    /*
    Function: FileReader
    Author: Daniel Meyer
    Description: Default constructor for FileReader class
    Input: N/A
    Output: N/A
    */
    public FileReader()
    {
        openFile();
    }
    
    /*
    Function: openFile
    Author: Daniel Meyer
    Description: Opens HashData.txt file
    Input: N/A
    Output: Error if file is not fount
    */
    private void openFile()
    {
        try
        {
            FileInputStream fis = new FileInputStream("HashData.txt");
            readFile("HashData.txt");
        }
        catch(FileNotFoundException fe)
        {
            System.out.println("File not found.");
        }
    }
    
    /*
    Function: readFile
    Author: Daniel Meyer
    Description: Reads each line in file and stores it in array list as strings
    Input: String for file name
    Output: Error if line cannot be read
    */
    private void readFile(String fname)
    {
        String input;
        FileInputStream fs = null;
        BufferedReader br = null;
        
        try
        {
            fs = new FileInputStream(fname);
            br = new BufferedReader(new InputStreamReader(fs));
            while((input = br.readLine()) != null)
            {
                strList.add(input);
            }
        }
        catch(IOException ie)
        {
            System.out.println("Unable to read line");
        }
        finally
        {
            try
            {
                if(br != null)
                {
                    br.close();
                }
            }
            catch(IOException ie)
            {
                System.out.println(ie.getMessage());
            }
        }
    }
    
    /*
    Function: getList
    Author: Daniel Meyer
    Description: Returns array list of strings holding each line in file
    Input: N/A
    Output: Array list of strings
    */
    public ArrayList<String> getList()
    {
        return strList;
    }
}
