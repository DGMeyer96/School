/*
Daniel Meyer
0405182
5-2-16
Assignment 13
Application of the Hash Table
 */
package data.str.assignment.pkg13;

import java.util.ArrayList;
import java.util.Scanner;

/*
Class: DataStrAssignment13
Author: Daniel Meyer
Description: Test class for modified hash table and node classes
Input: String for name to search for and char for choice of whether to continue searching
Output: Name and its corresponding phone number as a String
*/
public class DataStrAssignment13 
{
    
    /*
    Function: main
    Author: Daniel Meyer
    Description: main function for modified hash table and node classes
    Input: String for name to search for and char for choice of whether to continue searching
    Output: Name and its corresponding phone number as a String
    */
    public static void main(String[] args) 
    {
        String choice = "y";
        String key;
        long phoneNumber = 0;
        
        Scanner in = new Scanner(System.in);
        
        FileReader fr = new FileReader();
        
        ArrayList<String> list = fr.getList();
        
        HashTable ht = new HashTable(53);
        
        for(String str : list)
        {
            int i = 0;
            key = "";
            
            while(str.charAt(i) != ';')
            {
                key += str.charAt(i);
                i++;
            }

            String strNum = str.replaceAll("\\D+","");
            phoneNumber = Long.parseLong(strNum);
            ht.hash(key, phoneNumber);
        }
        
        while(!choice.toUpperCase().equals("N"))
        {
            System.out.println("Enter a name: ");
            System.out.println(ht.search(in.nextLine()));
            System.out.println("Look up another number? <Y/N>");
            choice = in.nextLine();
        }
    }
    
}
