/*
Daniel Meyer
0405182
2-10-16
Inheritance and Excpetion Handling
 */
package data.str.assignment.pkg4;

import java.util.Scanner;

/*
Class: DataStrAssignment4
Author: Daniel Meyer
Description: Test class for CharException and BigDecimalException
Inputs: N/A
Outputs: test Strings, Error Strings
*/

/*
Function: main
Author: Daniel Meyer
Description: Tests custom exceptions: CharException and BigDecimalException
Inputs: N/A
Outputs: test Strings, Error Strings
*/

public class DataStrAssignment4 
{   
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        
        Char ch = new Char('A');
        Char c = new Char('B');
        
        System.out.println(ch.add(c));
        System.out.println(ch.toChar() + " In Hex: " + ch.toHexString());
        System.out.println(ch.toChar() + " In Decimal: " + ch.toInt());
        
        try
        {
            System.out.println("Try to set 140 as character");
            int i = in.nextInt();
            ch.equals(i);
            System.out.println(ch.toChar());
        }
        catch(CharException ce)
        {
            System.out.println(ce.getError());
        }
        Char x = new Char(c);
        System.out.println(x.toString());
        
        
        
        String str;
        
        System.out.println("Enter a number with 2 or more decimals or non-digits");
        str = in.next();
        try
        {
            BigDecimal bd = new BigDecimal(str);
        }
        catch(BigDecimalException bde)
        {
            System.out.println(bde.getError());
        }
    }
    
}
