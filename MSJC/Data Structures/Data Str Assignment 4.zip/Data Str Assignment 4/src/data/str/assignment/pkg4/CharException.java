/*
Daniel Meyer
0405182
2-10-16
Inheritance and Excpetion Handling
 */
package data.str.assignment.pkg4;

/*
Class: CharException
Author: Daniel Meyer
Description: Custom exception for ints converted in Char class
Inputs: N/A
Outputs: Error message as string
*/

/*
Function: CharException
Author: Daniel Meyer
Description: Sets error message
Inputs: N/A
Outputs: N/A
*/

/*
Function: getError
Author: Daniel Meyer
Description: Accessor that returns error message
Inputs: N/A
Outputs: Error message as string
*/

public class CharException extends Exception
{
    private String error;
    
    public CharException()
    {
        /*
        Char ch = new Char(c);
        
        int i = (int)ch.toChar();
        
        if(i <= 32 || i >= 127)
        {
            error = "Invalid Character";
        }
        */
        
        error = "Invalid Character";
    }
    
    public String getError()
    {
        return error;
    }
}
