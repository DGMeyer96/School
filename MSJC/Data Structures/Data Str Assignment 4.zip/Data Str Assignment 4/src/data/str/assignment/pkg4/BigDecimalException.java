/*
Daniel Meyer
0405182
2-10-16
Inheritance and Excpetion Handling
 */
package data.str.assignment.pkg4;

/*
Class: 
Author: Daniel Meyer
Description: 
Inputs: N/A
Outputs: Error message as string
*/

/*
Function: BigDecimalException
Author: Daniel Meyer
Description: Overloaded constructor for when there is an invalid digit
Inputs: char to signal invalid digit
Outputs: N/A
*/

/*
Function: BigDecimalException
Author: Daniel Meyer
Description: Overloaded constructor for when there is are too many decimals
Inputs: int to signal too many decimals
Outputs: N/A
*/

/*
Function: getError
Author: Daniel Meyer
Description: Accessor that returns error message
Inputs: N/A
Outputs: Error message as string
*/

public class BigDecimalException extends Exception
{
    private String error;
    
    public BigDecimalException(char digit)
    {
        error = "Invalid Digit";
    }
    
    public BigDecimalException(int decimals)
    {
        error = "Too many decimals";
    }
    
    public String getError()
    {
        return error;
    }
}
