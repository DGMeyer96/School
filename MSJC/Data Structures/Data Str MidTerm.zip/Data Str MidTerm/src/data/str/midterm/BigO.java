/*
Daniel Meyer
0405182
2-22-16
Midterm
 */
package data.str.midterm;

/*
Class: BigO
Author: Daniel Meyer
Description: Class to test Big-Oh Notation functions
Inputs: N/A
Outputs: Sums as strings
*/

public class BigO 
{
    private int sum, i, j, k;
    
    /* //for testing calculation time to form graph
    private long startTime;
    private long endTime;
    private long totalTime;
    
    startTime = System.currentTimeMillis();
    
    endTime = System.currentTimeMillis();
    totalTime = endTime - startTime;
    System.out.println("Total TIme: " + totalTime);
    */
    
    
    
    /*
    Class: BigO
    Author: Daniel Meyer
    Description: Constructor to test Big-Oh notation functions
    Inputs: N/A
    Outputs: Sums as strings
    */
    public BigO(int n)
    {   
        linear(n);
        System.out.println("" + sum);
        
        quadratic1(n);
        System.out.println("" + sum);
        
        cubic(n);
        System.out.println("" + sum);
        
        quadratic2(n);
        System.out.println("" + sum);
        
        exponential(n);
        System.out.println("" + sum);
        
        logarithmic(n);
        System.out.println("" + sum);
    }
    
    /*
    Class: linear
    Author: Daniel Meyer
    Description: Linear O(N) functions
    Inputs: N/A
    Outputs: N/A
    */
    public void linear(int n) //O(N)
    {  
        sum = 0;
        for(i = 0; i < n; i++) //N is checked once, linear
        {
            sum++;
        }
    }
    
    /*
    Class: quadratic1
    Author: Daniel Meyer
    Description: Quadratic O(N^2) functions
    Inputs: N/A
    Outputs: N/A
    */
    public void quadratic1(int n) //O(N^2)
    {
        sum = 0;
        for(i = 0; i < n; i++) //N is checked
        {
            for(j = 0; j < n; j++) //N is checked
            {
                sum++;
            }
        }
    }
    
    /*
    Class: cubic
    Author: Daniel Meyer
    Description: Cubic O(N^3) functions
    Inputs: N/A
    Outputs: N/A
    */
    public void cubic(int n) //O(N^3)
    {
        sum = 0;
        for(i = 0; i < n; i++) //N is checked
        {
            for(j = 0; j < n * n; j++) //N is checked twice with N^2
            {
                sum++;
            }
        }
    }
    
    /*
    Class: quadratic2
    Author: Daniel Meyer
    Description: Quadratic O(N^2) functions
    Inputs: N/A
    Outputs: N/A
    */
    public void quadratic2(int n) //O(N^2)
    {
        sum = 0;
        for(i = 0; i < n; i++) //N is checked
        {
            for(j = 0; j < i; j++) //N is checked with N - 1, drop constants b/c worst case
            {                      //looking for how function scales
                sum++;
            }
        }
    }
    
    /*
    Class: exponential
    Author: Daniel Meyer
    Description: Exponential O(N log N) functions
    Inputs: N/A
    Outputs: N/A
    */
    public void exponential(int n) //O(N log N)
    {
        sum = 0;
        for(i = 0; i < n; i++) //n is checked
        {
            for(j = 0; j < i * i; j++) //n is checked with i
            {
                for(k = 0; k < j; k++) //n is checked with j
                {
                    sum++; //Growth increases over time similar to N^X or X log N
                }
            }
        }
    }
    
    /*
    Class: logarithmic
    Author: Daniel Meyer
    Description: Logarithmic O(log N) functions
    Inputs: N/A
    Outputs: N/A
    */
    public void logarithmic(int n) //O(log N)
    {
        sum = 0;
        for(i = 1; i < n; i++) //N is checked
        {
            for(j = 1; j < i * i; j++) //N is checked
            {
                if(j % i == 0)
                {
                    for(k = 0; k < j; k++) //N isn't always checked so not counted
                    {
                        sum++; //Growth decreases over time
                    }
                }
            }
        }
    }
}
