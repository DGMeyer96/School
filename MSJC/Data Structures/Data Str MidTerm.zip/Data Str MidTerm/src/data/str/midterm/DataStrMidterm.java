/*
Daniel Meyer
0405182
2-22-16
Midterm
 */
package data.str.midterm;

import java.util.Scanner;

/*
Class: DataStrMidterm
Author: Daniel Meyer
Description: Class to test Big-Oh Notation functions
Inputs: N/A
Outputs: N/A
*/

public class DataStrMidterm 
{
    
    /*
    Function: main
    Author: Daniel Meyer
    Description: Main function for testing BigO class
    Inputs: Int for N times to run calculations
    Outputs: N/A
    */
    
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter an int");
        int n = in.nextInt();
        
        BigO bo = new BigO(n);
    }
    
}
