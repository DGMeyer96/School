/*
Daniel Meyer
0405182
5-9-16
Assignment 14
Sorting
 */
package data.str.assignment.pkg14;

import java.util.Random;

/*
Class: Sorter
Author: Daniel Meyer
Description: Class that implements 4 different sort algorithms and sorts an array of doubles
Input: Its for range for random number generator and beginning and end of array as well as an array to sort
Output: Number of iterations needed to sort array
*/
public class Sorter 
{
    private double[] List;
    private int Size;
    
    Timer time = new Timer();
    
    /*
    Function: Sorter
    Author: Daniel Meyer
    Description: Default constructor that randomly fills a random sized array of doubles
    Input: N/A
    Output: N/A
    */
    public Sorter()
    {
        Random rand = new Random();
        int size = rand.nextInt(100);
        
        this.List = new double[size];
        this.Size = size;
        
        for(int i = 0; i < size; i++)
        {
            double dbl = rand.nextDouble();
            this.List[i] = dbl;
        }
    }
    
    /*
    Function: Sorter
    Author: Daniel Meyer
    Description: Overloaded constructor that sets range for random number generator 
    Input: Ints for minimum and maximum range for random number generator
    Output: Array size to console
    */
    public Sorter(int max, int min)
    {
        Random rand = new Random();
        int size = rand.nextInt(100);
        
        this.List = new double[size];
        this.Size = size;
        
        for(int i = 0; i < size; i++)
        {
            double dbl = (rand.nextDouble() / max) * (max - min) + min;
            add(dbl, i);
        }
        
        System.out.println("Array size: " + size);
        printList();
    }
    
    /*
    Function: resizeList
    Author: Daniel Meyer
    Description: Resizes the array
    Input: Int for new size of array
    Output: N/A
    */
    public void resizeList(int size)
    {
        double[] temp = this.List;
        
        this.List = new double[size];
        
        for(int i = 0; i < temp.length; i++)
        {
            this.List[i] = temp[i];
        }
    }
    
    /*
    Function: add
    Author: Daniel Meyer
    Description: Adds a double to the array at the specified index
    Input: Double to add to array and int for index in array
    Output: N/A
    */
    private void add(double data, int i)
    {
        this.List[i] = data;
    }
    
    /*
    Function: insertionSort
    Author: Daniel Meyer
    Description: Insertion type sort algorithm and increments for each iteration
    Input: Array of doubles to sort and int for last index in list
    Output: N/A
    */
    private void insertionSort(double[] list, int last)
    {
        double hold = 0;
        int search = 0;
        
        for(int current = 1; current <= last; current++)
        {
            hold = list[current];
            
            for(search = current - 1; search >= 0 && hold < list[search]; search--)
            {
                list[search + 1] = list[search];
            }
            
            list[search + 1] = hold;
            
            time.increment();
        }
    }
    
    /*
    Function: insertionSort
    Author: Daniel Meyer
    Description: Accessor for insertionSort function
    Input: N/A
    Output: Number of iterations the insertion sort algorithm used to sort the array
    */
    public void insertionSort()
    {
        double[] list = this.List;
        this.insertionSort(list, Size - 1);
        
        System.out.println("Number of iterations for Insertion Sort: " + time.getIterations());
        time.resetCount();
    }
    
    /*
    Function: selectionSort
    Author: Daniel Meyer
    Description: Selection type sort algorithm and increments for each iteration
    Input: Array of doubles to sort and int for last index in list
    Output: N/A
    */
    private void selectionSort(double[] list, int last)
    {
        int smallest = 0;
        double holdData = 0;
        
        for(int current = 0; current < last; current++)
        {
            smallest = current;
            
            for(int i = current + 1; i <= last; i++)
            {
                if(list[i] < list[smallest])
                {
                    smallest = i;
                }
            }
            
            holdData = list[current];
            list[current] = list[smallest];
            list[smallest] = holdData;
            
            time.increment();
        }
    }
    
    /*
    Function: selectionSort
    Author: Daniel Meyer
    Description: Accessor for selectionSort function
    Input: N/A
    Output: Number of iterations the selection sort algorithm used to sort the array
    */
    public void selectionSort()
    {
        double[] list = this.List;
        this.selectionSort(list, Size - 1);
        
        System.out.println("Number of iterations for Selection Sort: " + time.getIterations());
        time.resetCount();
    }
    
    /*
    Function: quickSort
    Author: Daniel Meyer
    Description: Quick type sort algorithm and increments for each iteration
    Input: Array of doubles to sort and int for first and last index in list
    Output: N/A
    */
    private void quickSort(double[] list, int m, int n)
    {
        double key;
        
        int i, j, k;
        
        if(m < n)
        {
            k = choosePivot(m, n);
            swap(list, m, k);
            key = list[m];
            i = m + 1;
            j = n;
            
            while(i <= j)
            {
                while((i <= n) && (list[i] <= key))
                {
                    i++;
                }
                
                while((j >= m) && (list[j] > key))
                {
                    j--;
                }
                
                while(i < j)
                {
                    swap(list, i, j);
                }
            }
            
            swap(list, m, j);
            
            quickSort(list, m, j - 1);
            quickSort(list, j + 1, n); 
            
            //time.increment();
        }
        
        time.increment();
    }
    
    /*
    Function: choosePivot
    Author: Daniel Meyer
    Description: Gets the pivot point for the quick sort algorithm between two indexes
    Input: Int for left and right indexes to find pivot point for
    Output: Int for index of pivot
    */
    private int choosePivot(int l, int r)
    {
        return(l + r) / 2;
    }
    
    /*
    Function: swap
    Author: Daniel Meyer
    Description: Swaps values in the specified indexes in the specified array
    Input: Array of doubles and ints for indexes to swap in the array
    Output: N/A
    */
    private void swap(double[] list, int m, int k)
    {
        double tmp = list[m];
        list[m] = list[k];
        list[k] = tmp;
    }
    
    /*
    Function: quickSort
    Author: Daniel Meyer
    Description: Accessor for quickSort function
    Input: N/A
    Output: Number of iterations the quick sort algorithm used to sort the array
    */
    public void quickSort()
    {
        double[] list = this.List;
        this.quickSort(list, 0, Size - 1);
        
        System.out.println("Number of iterations for Quick Sort: " + time.getIterations());
        time.resetCount();
    }
    
    /*
    Function: mergeSort
    Author: Daniel Meyer
    Description: Merge type sort algorithm and increments for ech iteration
    Input: Array list of doubles and ints for first and last indexes
    Output: N/A
    */
    private void mergeSort(double[] list, int low, int high)
    {
        int mid;
        
        if(low < high)
        {
            mid = (high + low) / 2;
            
            mergeSort(list, low, mid);
            mergeSort(list, mid + 1, high);
            
            merge(list, low, mid, high);
            
            time.increment();
        }   
    }
    
    /*
    Function: merge
    Author: Daniel Meyer
    Description: Merges "two" arrays to make a "third" array of sorted values
    Input: Array list of doubles and ints for 3 different indexes
    Output: N/A
    */
    private void merge(double[] list, int low, int mid, int high)
    {
        int i, j ,k;
        double[] tmp = new double[this.Size];
        
        i = low;
        j = mid + 1;
        k = low;
        
        while((i <= mid) && (j <= high))
        {
            if(list[i] < list[j])
            {
                tmp[k] = list[i];
                k++;
                i++;
            }
            else
            {
                tmp[k] = list[j];
                k++;
                j++;
            }
        }
        
        while(i <= mid)
        {
            tmp[k] = list[i];
            k++;
            i++;
        }
        
        while(j <= high)
        {
            tmp[k] = list[j];
            k++;
            j++;
        }
        
        for(i = low; i < k; i++)
        {
            list[i] = tmp[i];
        }
    }
    
    /*
    Function: mergeSort
    Author: Daniel Meyer
    Description: Accessor for mergeSort function
    Input: N/A
    Output: Number of iterations the merge sort algorithm used to sort the array
    */
    public void mergeSort()
    {
        double[] list = this.List;
        this.mergeSort(list, 0, Size - 1);
        
        System.out.println("Number of iterations for Merge Sort: " + time.getIterations());
        time.resetCount();
    }
    
    /*
    Function: getList
    Author: Daniel Meyer
    Description: Returns the primary array of doubles
    Input: N/A
    Output: Array of doubles
    */
    public double[] getList()
    {
        return this.List;
    }
    
    /*
    Function: printList
    Author: Daniel Meyer
    Description: Prints the primary array of doubles
    Input: N/A
    Output: Each double in array
    */
    public void printList()
    {
        for(double dbl : this.List)
        {
            System.out.println("" + dbl);
        }
    }
    
    /*
    Function: printList
    Author: Daniel Meyer
    Description: Overloaded function that prints a specified array of doubles
    Input: N/A
    Output: Each double in array
    */
    public void printList(double[] list)
    {
        for(double dbl : list)
        {
            System.out.println("" + dbl);
        }
    }
}
