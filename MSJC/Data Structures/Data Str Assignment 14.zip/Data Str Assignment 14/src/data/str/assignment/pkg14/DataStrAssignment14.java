/*
Daniel Meyer
0405182
5-9-16
Assignment 14
Sorting
 */
package data.str.assignment.pkg14;

/*
Class: DataStrAssignment14
Author: Daniel Meyer
Description: Test class for Sorter and Timer classes
Input: N/A
Output: Time it took to sort array and number of iterations to do so
*/
public class DataStrAssignment14 
{

    /*
    Function: main
    Author: Daniel Meyer
    Description: Test function for Sorter and Timer classes
    Input: N/A
    Output: Time it took to sort array and number of iterations to do so
    */
    public static void main(String[] args) 
    {
        Timer time = new Timer();
        
        Sorter sort = new Sorter(1, 100);
        
        time.startTimer();
        sort.insertionSort();
        time.stopTimer();
        System.out.println("Time for Insertion Sort: " + time.getTime() + " nano seconds");
        
        time.startTimer();
        sort.selectionSort(); 
        time.stopTimer();
        System.out.println("Time for Selection Sort: " + time.getTime() + " nano seconds");
        
        time.startTimer();
        sort.quickSort();
        time.stopTimer();
        System.out.println("Time for Quick Sort: " + time.getTime() + " nano seconds");
        
        time.startTimer();
        sort.mergeSort(); 
        time.stopTimer();
        System.out.println("Time for Merge Sort: " + time.getTime() + " nano seconds");
        
        //I believe the merge sort algorithm is the most efficient as it breaks
        //down the array into smaler, simpler porblems, and quickly reassembles
        //the multiple smaller arrays into a full sized, sorted array.
        //I would have initially said the quick sort is the fastest, however
        //it has to make the most iterations and is only sometimes the fastest.
        //The other sort methods' speed change depending on how much the lists
        //are already sorted naturally whereas the merge sort is more consistent.
        //Furthermore the merge sort is also friendly when it comes to using
        //external data such as files which are more common in real world
        //scenarios.
    }
    
}
