/*
Daniel Meyer
0405182
5-9-16
Assignment 14
Sorting
 */
package data.str.assignment.pkg14;

/*
Class: Timer
Author: Daniel Meyer
Description: Class that checks how long it took to perform a sort and how many iterations it took
Input: N/A
Output: Total time and number of iterations
*/
public class Timer 
{
    private long totalTime;
    private long startTime;
    private long endTime;
    private int numIterations = 0;
    
    /*
    Function: startTimer
    Author: Daniel Meyer
    Description: Starts the timer by getting current system time in nano seconds
    Input: N/A
    Output: N/A
    */
    public void startTimer()
    {
        this.startTime = System.nanoTime();
    }
    
    /*
    Function: stopTimer
    Author: Daniel Meyer
    Description: Stops the timer by getting current system time in nano seconds
    Input: N/A
    Output: N/A
    */
    public void stopTimer()
    {
        this.endTime = System.nanoTime();
    }
    
    /*
    Function: getTime
    Author: Daniel Meyer
    Description: Gets total time from difference between start and end time
    Input: N/A
    Output: Final time in nano seconds
    */
    public long getTime()
    {
        this.totalTime = endTime - startTime;
        return this.totalTime;
    }
    
    /*
    Function: increment
    Author: Daniel Meyer
    Description: Increments the number of iterations
    Input: N/A
    Output: N/A
    */
    public void increment()
    {
        this.numIterations++;
    }
    
    /*
    Function: getIterations
    Author: Daniel Meyer
    Description: Returns the number of iterations
    Input: N/A
    Output: Number of iterations as an int
    */
    public int getIterations()
    {
        return this.numIterations;
    }
    
    /*
    Function: resetTimer
    Author: Daniel Meyer
    Description: Sets toal, start, and end time to 0
    Input: N/A
    Output: N/A
    */
    public void resetTimer()
    {
        this.totalTime = 0;
        this.startTime = 0;
        this.endTime = 0;
    }
    
    /*
    Function: resetCount
    Author: Daniel Meyer
    Description: Sets number of iterations to 0
    Input: N/A
    Output: N/A
    */
    public void resetCount()
    {
        this.numIterations = 0;
    }
}
