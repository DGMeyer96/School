/*
Daniel Meyer
0405182
3-7-16
Assignment 7
Doubly Linked Lists
 */
package data.str.assignment.pkg7;

/*
Class: Stack
Author: Daniel Meyer
Description: Stack class that holds generics
Inputs: Generic to add to top of stack
Outputs: Generic on top of stack and each generic in stack
*/
public class Stack<G> extends DoublyLinked
{
    /*
    Function: push
    Author: Daniel Meyer
    Description: Adds a generic to the top of the stack
    Inputs: A generic to add to the top of the stack
    Outputs: N/A
    */
    public void push(G data)
    {
        super.addFront(data);
    }
    
    /*
    Function: pop
    Author: Daniel Meyer
    Description: Removes generic at top of stack and returns it
    Inputs: N/A
    Outputs: Generic removed from top of stack
    */
    public G pop()
    {
        DoublyLinked<G> top = super.deleteFront();
        top = super.Head;
        
        if(top.Data == null)
        {
            return null;
        }
        else
        {
            return top.Data;
        }
    }
    
    /*
    Function: peek
    Author: Daniel Meyer
    Description: Returns the generic on the top of the stack without removing it
    Inputs: N/A
    Outputs: Generic at the top of the stack
    */
    public G peek()
    {
        DoublyLinked<G> data = super.Head;
        
        if(data.Data == null)
        {
            return null;
        }
        else
        {
            return data.Data;
        }
    }
    
    /*
    Function: printStack
    Author: Daniel Meyer
    Description: Prints the contents of the stack
    Inputs: N/A
    Outputs: The contents of the stack
    */
    public void printStack()
    {
        DoublyLinked<G> start = super.Head;
        
        System.out.println("Stack: ");
        
        while(start != null)
        {
            System.out.println(start.Data);
            start = start.Next;
        }
    }
}
