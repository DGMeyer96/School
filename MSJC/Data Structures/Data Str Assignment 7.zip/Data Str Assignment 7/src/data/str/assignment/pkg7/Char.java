/*
Daniel Meyer
0405182
3-7-16
Assignment 7
Doubly Linked Lists
 */
package data.str.assignment.pkg7;

/*
Class: Char
Author: Daniel Meyer
Description: A complex type called Char that mimics the attributes of the char primitive
Inputs: char, int, Char, and String that are stored in the primitive char
Outputs: a char as a String, char, Char, int, or Hexidecimal String
*/
public class Char
{
    private char ch;
        
        /*
    Function: Char
    Author: Daniel Meyer
    Description: This function is the default constructor that sets the data section to null.
    Outputs: N/A 
    */
    public Char()
    {
        this.ch = 0; // null/0
    }
     
    /*
    Function: Char
    Author: Daniel Meyer
    Description: This function is an overloaded constructor that sets the data section to a char.
    Inputs: A char that is assigned to the data section.
    Outputs: N/A 
    */
    public Char(char c)
    {
        equals(c);
    }
       
    /*
    Function: Char
    Author: Daniel Meyer
    Description: This function is an overloaded constructor that sets the data section to an int.
    Inputs: An int that is assigned to the data section.
    Outputs: N/A 
    */
    public Char(int c)
    {
        equals(c);
    }
        
    /*
    Function: Char
    Author: Daniel Meyer
    Description: This function is an overloaded constructor that sets the data section to a Char.
    Inputs: A Char type that is assigned to the data section.
    Outputs: N/A 
    */
    public Char(final Char c)
    {
        equals(c);
    }
    
    /*
    Function: Char
    Author: Daniel Meyer
    Description: This function is an overloaded constructor that sets the data section to a String.
    Inputs: A String that is assigned to the data section.
    Outputs: N/A 
    */
    public Char(String c)
    {
        equals(c.charAt(0)); 
    }
    
    /*
    Function: equals
    Author: Daniel Meyer
    Description: A mutator that sets the data section to a Char type.
    Inputs: A Char type that is assigned to the data section.
    Outputs: N/A 
    */
    public void equals(final Char c)
    {
        this.ch = c.ch; //c.ch invokes class to store into char type 
    }
    
    /*
    Function: equals
    Author: Daniel Meyer
    Description: A mutator that sets the data section to a char.
    Inputs: A char that is assigned to the data section.
    Outputs: N/A 
    */
    public void equals(char c)
    {
        Character character = c;
        this.ch = character;
    }
     
    /*
    Function: equals
    Author: Daniel Meyer
    Description: A mutator that sets the data section to an int.
    Inputs: An int that is assigned to the data section.
    Outputs: N/A 
    */   
    public void equals(int c)
    {
        Character character = (char)c; //converts int to char equivalent
        this.ch = character;
    }
               
    /*
    Function: toChar
    Author: Daniel Meyer
    Description: An accessor that returns the data section as a char.
    Inputs: N/A
    Outputs: The data section is returned as a character.
    */    
    public char toChar()
    {
        Character character = this.ch;
        return character;
    }
        
    /*
    Function: toInt
    Author: Daniel Meyer
    Description: An accessor that returns the data section as an int.
    Inputs: N/A
    Outputs: The data section is returned as an int.
    */
    public int toInt()
    {   
        Integer i = new Integer(this.ch);
        return i;
    }
       
    /*
    Function: toString
    Author: Daniel Meyer
    Description: An accessor that returns the data section as a String.
    Inputs: N/A
    Outputs: The data section is returned as a String.
    */
    public String toString()
    {
        String str = "" + this.ch;
        return str;
    }
       
    /*
    Function: toHextString
    Author: Daniel Meyer
    Description: An accessor that returns the data section as a Hexidecimal String.
    Inputs: N/A
    Outputs: The data section is returned as a Hexidecimal String.
    */
    public String toHexString()
    {
        String hexStr = Integer.toHexString(this.ch);
        return hexStr;
    }
        
    /*
    Function: add
    Author: Daniel Meyer
    Description: A function that concatenates the data section and a char.
    Inputs: A char to concatenate to the data section.
    Outputs: Returns the concatenated data section and char.
    */
    public String add(char c)
    {
        String str = "" + toString() + "" + c;
        return str;
    }
       
    /*
    Function: add
    Author: Daniel Meyer
    Description: A function that concatenates the data section and a Char type.
    Inputs: A Char type to concatenate to the data section.
    Outputs: Returns the concatenated data section and Char type.
    */
    public String add(final Char c)
    {
        String str = "" + toString() + "" + c.toString();
        return str;
    }
}
