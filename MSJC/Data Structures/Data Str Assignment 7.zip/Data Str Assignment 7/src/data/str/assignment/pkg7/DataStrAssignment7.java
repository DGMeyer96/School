/*
Daniel Meyer
0405182
3-7-16
Assignment 7
Doubly Linked Lists
 */
package data.str.assignment.pkg7;

/*
Class: DataStrAssignment7
Author: Daniel Meyer
Description: Test class for Stack and Queue classes
Input: N/A
Output: Strings to console showing contents and tops of Stack and Queue
*/
public class DataStrAssignment7 
{
    /*
    Function: main
    Author: Daniel Meyer
    Description: Tests Stack and Queue classes
    Input: N/A
    Output: Strings to console showing contents and tops of Stack and Queue
    */
    public static void main(String[] args) 
    {   
        BigDecimal a = new BigDecimal("121.4858683938594395839395456");
        BigDecimal b = new BigDecimal("120.3859303402940358930493204333");
        
        Stack s = new Stack();
        s.push(a); //adds BigDecimal to top of stack
        System.out.println("Current top: " + s.peek()); //Prints top of stack to check BigDecimal was added
        s.push(b); //adds BigDecimal to top of stack
        System.out.println("Current top: " + s.peek()); //Prints top of stack to check BigDecimal was added
        s.printStack(); //Prints stack to ensure data was added
        System.out.println("New top: " + s.pop()); //Removes top and prints to ensure it was remvoed
        s.printStack(); //Prints stack to ensure data was removed
        s.pop(); //Removes last item in stack and replaces it with null
        s.printStack(); //Prints stack to ensure data was removed
        
        Queue q = new Queue();
        q.enqueue(a); //adds data BigDecimal to queue
        q.enqueue(b); //adds data BigDecimal to queue
        System.out.println("\n" + "Current top: " + q.peek()); //Checks top of queue
        q.printQueue(); //Prints queue to ensure all data is there
        q.dequeue(); //removes top item in queue
        q.printQueue(); //Prints queue to ensure data was removed
    }
    
}
