/*
Daniel Meyer
0405182
5-23-16
Final
A Rat in a Maze Problem
 */
package data.str.pkgfinal;

import java.util.LinkedList;
import java.util.Random;

/*
Class: Maze
Author: Daniel Meyer
Description: Creates a maze for a rat to solve using an adjacency list and recursion
Input: Ints for number of rows and columns for maze and the number of obstacles
Output: Prints the maze to the console
*/
public class Maze 
{
    /*
    If rat goes left or right then it moves foward or backward in the linked list
    If rat goes up or down it moves to another linked list
    X coords = linked list (edges)
    Y coords = array (vertices)
    */
    
    private LinkedList<Node>[] adjMatrix;
    
    private int Vertices;
    private int Edges;
    private int Obstacles;
    
    /*
    Function: Maze
    Author: Daniel Meyer
    Description: Default constructor that assembles the maze with a default number of rows, columns, and obstacles
    Input: N/A
    Output: N/A
    */
    public Maze()
    {
        Vertices = 10;
        Edges = 20;
        Obstacles = 15;
        
        adjMatrix = new LinkedList[Vertices];
        
        buildWalls();
        addObstacles();
        makeExit();
    }
    
    /*
    Function: Maze
    Author: Daniel Meyer
    Description: Overloaded construct that assembles the maze with the given nubmer of rows, columns, and obstacles
    Input: Ints for number of rows and columns for maze and the number of obstacles
    Output: N/A
    */
    public Maze(int rows, int cols, int obs)
    {
        Vertices = rows;
        Edges = cols;
        Obstacles = obs;
        
        adjMatrix = new LinkedList[Vertices];
        
        buildWalls();
        addObstacles();
        makeExit();
    }
    
    /*
    Function: buildWalls
    Author: Daniel Meyer
    Description: Fills the maze and sets the bordering nodes to walls
    Input: N/A
    Output: N/A
    */
    private void buildWalls()
    {
        for(int i = 0; i < Vertices; i++)
        {
            adjMatrix[i] = new LinkedList<>();
            
            Node n = new Node();
            n.makeWall();
            adjMatrix[i].addFirst(n);
            
            for(int j = 0; j < Edges; j++)
            {
                if(i == 0 | i == Vertices - 1)
                {
                    n = new Node();
                    n.makeWall();
                    adjMatrix[i].add(n);
                }
                else if(j == Edges - 2)
                {
                    n = new Node();
                    n.makeWall();
                    adjMatrix[i].add(n);
                }
                else
                {
                    n = new Node();
                    adjMatrix[i].add(n);
                }
            }
        }
    }
    
    /*
    Function: addObstacles
    Author: Daniel Meyer
    Description: Fills the maze with wall nodes at random vertices and edges
    Input: N/A
    Output: N/A
    */
    private void addObstacles()
    {
        Random rdm = new Random();
        
        for(int i = 0; i < Obstacles; i++)
        {
            int v = rdm.nextInt((Vertices - 1) - 1) + 1;
            int e = rdm.nextInt((Edges - 1) - 1) + 1;
            
            Node n = adjMatrix[v].remove(e);
            n.makeWall();
            adjMatrix[v].add(e, n);
        }
    }
    
    /*
    Function: makeExit
    Author: Daniel Meyer
    Description: Creates an exit node in the bottom right of the maze
    Input: N/A
    Output: N/A
    */
    private void makeExit()
    {
        Node n = adjMatrix[Vertices - 2].remove(Edges - 2);
        n.makeExit();
        adjMatrix[Vertices - 2].add(Edges - 2, n);
    }
    
    /*
    Function: solveMaze
    Author: Daniel Meyer
    Description: Recursive function that attempts to move the rat in a direction until a solution is found if it exists
    Input: Ints for starting vertex and edge
    Output: Boolean for whether or not the maze has a solution
    */
    private boolean solveMaze(int v, int e)
    {
        if(v == Vertices - 2 && e == Edges - 2)
        {
            Node rat = adjMatrix[v].remove(e);
            rat.makeRat();
            adjMatrix[v].add(e, rat);
            
            return true;
        }
        else if(isOpen(v, e) == true)
        {
            Node rat = adjMatrix[v].remove(e);
            rat.makeRat();
            adjMatrix[v].add(e, rat);
            
            if(solveMaze(v + 1, e) == true)
            {
                return true;
            }
            else if(solveMaze(v, e + 1) == true)
            {
                return true;
            }
            else
            {
                Node n = adjMatrix[v].remove(e);
                n = new Node();
                adjMatrix[v].add(e, n);
                
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    
    /*
    Function: solveMaze
    Author: Daniel Meyer
    Description: Function that calls a recursive function to solve the maze
    Input: N/A
    Output: Returns true if there is a solution and prints it or false if no solution
    */
    public boolean solveMaze()
    {
        if(this.solveMaze(1, 1) == false)
        {
            System.out.println("No solution");
            return false;
        }
        
        System.out.println("Solved Maze:");
        this.printMaze();
        return true;
    }
    
    /*
    Function: isOpen
    Author: Daniel Meyer
    Description: CHecks to see if the node is filled or an obstacle
    Input: Ints for vertex and edge of node to check
    Output: Boolean for whether or not the node is open
    */
    private boolean isOpen(int v, int e)
    {
        if(adjMatrix[v].get(e).Full == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /*
    Function: printMaze
    Author: Daniel Meyer
    Description: Prints the maze to the console
    Input: N/A
    Output: N/A
    */
    public void printMaze()
    {
        for(int i = 0; i < Vertices; i++)
        {
            for(int j = 0; j < Edges; j++)
            {
                Node n = adjMatrix[i].get(j);
                
                if(n.Visited == true)
                {
                    System.out.print(8);
                }
                else if(n.isExit == true)
                {
                    System.out.print(5);
                }
                else
                {
                    System.out.print(n.Full);
                }
            }
            
            System.out.println();
        }
    }
}
