/*
Daniel Meyer
0405182
5-23-16
Final
A Rat in a Maze Problem
 */
package data.str.pkgfinal;

/*
Class: DataStrFinal
Author: Daniel Meyer
Description: Test class for Maze class
Input: N/A
Output: An assembled maze and solved maze
*/
public class DataStrFinal 
{
    /*
    Function: main
    Author: Daniel Meyer
    Description: Test function for Maze class
    Input: N/A
    Output: An assembled maze and solved maze
    */
    public static void main(String[] args) 
    {
        Maze m = new Maze();
        m.printMaze();
        System.out.println();
        m.solveMaze();
    }
    
}
