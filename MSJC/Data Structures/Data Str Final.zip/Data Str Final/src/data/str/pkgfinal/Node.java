/*
Daniel Meyer
0405182
5-23-16
Final
A Rat in a Maze Problem
 */
package data.str.pkgfinal;

/*
Class: Node
Author: Daniel Meyer
Description: Class for holding information of each node in the maze
Input: N/A
Output: N/A
*/
public class Node 
{
    int Full; //one or zero for printing maze
    boolean Visited; //whether rat has been here
    boolean isWall; //is a wall
    boolean isExit; //is an exit
    
    /*
    Function: Node
    Author: Daniel Meyer
    Description: Default constructor for an empty node in the maze
    Input: N/A
    Output: N/A
    */
    public Node()
    {
        Full = 0;
        Visited = false;
        isWall = false;
        isExit = false;
    }
    
    /*
    Function: makeWall
    Author: Daniel Meyer
    Description: Sets the node to be a wall in the maze
    Input: N/A
    Output: N/A
    */
    public void makeWall()
    {
        Full = 1;
        isWall = true;
        isExit = false;
    }
    
    /*
    Function: makeExit
    Author: Daniel Meyer
    Description: Sets the node to be an exit in the maze
    Input: N/A
    Output: N/A
    */
    public void makeExit()
    {
        Full = 1;
        isExit = true;
        isWall = false;
    }
    
    /*
    Function: makeRat
    Author: Daniel Meyer
    Description: Sets the node to a space the rat has visited
    Input: N/A
    Output: N/A
    */
    public void makeRat()
    {
        Full = 1;
        Visited = true;
    }
}
